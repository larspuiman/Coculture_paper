
function visc = viscosity(T)
    % Temperature in Kelvin
    Const = [-24.71, 4.209e3, 4.527e-2, -3.376e-5];     % Constants for water (Reid, 1987)
    
    visc = exp(Const(1)+Const(2)*T^-1+Const(3)*T+Const(4)*T^2);  % mPa.s
    visc = visc/1000;                                       % Pa.s
end