function [dcdt, Fg_out, vol_rates, n_mt, vol_rates_bal] = str_fun_odedae(t, y, params, geom, cc_spec)
    
    % get concentrations
    c = y(1:8);
    % c_o2 = c(1);
    % c_h2 = c(2);
    % c_co2 = c(3);
    % c_ch4 = c(4)
    % c_nh4 = c(5);
    % c_phb = c(6);
    % c_x_nec = c(7);
    % c_x_caps = c(8);    

    % cc_spec is specifier which reactions happen
    % if cc_spec = 0, then Cn, if 1 then Mc, if 2 then both
    
    % gas in dispersion and headspace [O2, H2, CO2, CH4, N2, AR]
    n_species = length(params.y_in);
    y_D = y(9:9+n_species-1); 
    y_H = y(9+n_species:9+n_species*2-1);
    y_in = params.y_in';

    % if negative CO2 concentrations, make it 1e-16
    if y_D(3) < 0, y_D(3) = eps; end
    if y_H(3) < 0, y_H(3) = eps; end

    % constants
    surface_tension = 0.072;                    % Nm
    g = 9.81;                                   % gravity [m/s2]
    R = 8.314;                                      % J/mol/K
    MW = params.MW;
    rho_L = 998;                                % kg/m3
    rho_gas = sum(MW.*y_in)*params.P_gas/(R*params.Temp)/1000;
    ug_s = params.Fg_in/(1/4*pi*geom.D^2);      % superficial gas flow velocity [m/s]
    
    % formula for gas hold-up from Garcia Ochoa - solve using fzero
    fun = @(x) (x/(1-x) - 0.819 * (ug_s^(2/3)*params.rpm^(2/5)*geom.D_imp^(4/15))/(g^(1/3)) * ...
        (rho_L/surface_tension)^(1/5) * (rho_L/(rho_L-rho_gas) * (rho_L/rho_gas)^(-1/15)) );
    eps_G_0 = 0.01;                                   % gas hold-up
    eps_G = fzero(fun, eps_G_0);

%     eps_G = 0.6 * params.ug_s^0.7 * 4;

    % calculate volumes
    V_G_D = eps_G*geom.V_L;                         % approximate gas volume in dispersion
    V_G_H = geom.V_R - geom.V_L - V_G_D;            % gas volume in headspace                        
    
    % parameters
    diff = diffusion_coefficient(params.Temp,[]);               % range of diffusion coefficients [O2, H2, CO2, CH4]

    % solubility calculation -- assume high industrial kla 
    kla = params.kla_ch4*sqrt(diff/diff(4));                % kla values for all compounds (1/h) [O2, H2, CO2, CH4, N2]
        % solubilities
    y_sol = y_in(1:4)';
    c_sol = Henry(params.Temp)'*params.P_gas.*y_sol;         % g/L for [O2, H2, CO2, CH4, N2]
%     c_sol(3) = c_sol(3)/100;

    % kla prediction --> list of parameters
    Np = 2*5.9+1.6;                                                 % power number (5.9 Rushton, 1.6 pitched blade)
    PV = Np*rho_L*geom.D_imp^5*(params.rpm).^3 / geom.V_L;

    kla_riet = 0.026*(PV).^0.4 .* params.ug_s.^0.5 * 3600;                % kla [1/h]  
    kla_fit = 0.0615*(PV).^0.43 .* params.ug_s.^0.63 * 3600;                % kla [1/h]  



    % influence of mass transfer on gas flow and composition
    n_mt = kla'.*(c_sol-c(1:4));                    % transfer rate mol/m3/h for [O2, H2, CO2, CH4]

    % calculate gas outflow, if N2 is there it's the inert gas, otherwise
    % it's Ar.
    Fg_out = params.Fg_in- sum(n_mt)*geom.V_L*R*params.Temp/params.P_gas/3600;
    if y_in(5) == 0
        idx_cons = 6; idx_other = 5;
    else
        idx_cons = 5; idx_other = 6;
    end

    Fg_out = params.Fg_in*y_in(idx_cons)/y_H(idx_cons);

    if Fg_out < 0
        Fg_out = 0;
    end

    % reactions
    if cc_spec == 0             % Cn model only
        vol_rates_nec = kinetics_necator(c, 0, 0)';      % volumetric rates (g/L/h)
        vol_rates_cap = zeros(size(vol_rates_nec));         % volumetric rates (g/L/h)
    elseif cc_spec == 1         % Mc model only
        vol_rates_cap = kinetics_capsulatus(c)';         % volumetric rates (g/L/h)
        vol_rates_nec = zeros(size(vol_rates_cap));
    else                        % CC model only
        vol_rates_nec = kinetics_necator(c, 0, 0)';      % volumetric rates (g/L/h)
        vol_rates_cap = kinetics_capsulatus(c)';         % volumetric rates (g/L/h)
    end

    % inflow rate                       % g/L
    % O2, H2, CO2, CH4, NH4, PHB, X
    c_in = [0*c_sol', params.N_feed, 0, 0, 0];
    
    % derivatives - g/L/h
    dcdt(1:4) = n_mt(1:4) + vol_rates_nec(1:4) + vol_rates_cap(1:4) + params.Dil*(c_in(1:4)' - c(1:4));
    dcdt(5)   = vol_rates_nec(5) + vol_rates_cap(5) + params.Dil*(c_in(5) - c(5) );
    dcdt(6:8) = vol_rates_nec(6:8) + vol_rates_cap(6:8) + params.Dil*(c_in(6:8)' - c(6:8));
    
    dy_Ddt(1:4) = (params.Fg_in/V_G_D*params.y_in(1:4) - Fg_out/V_G_D*y_D(1:4))*3600 - ...
        geom.V_L/V_G_D * n_mt(1:4)./MW(1:4)'*1000*R*params.Temp/params.P_gas;
    dy_Ddt(idx_cons) =  y_D(idx_cons) - (1 - sum(y_D([1:4, idx_other])));
    dy_Ddt(idx_other) = (params.Fg_in/V_G_D*params.y_in(idx_other) - Fg_out/V_G_D*y_D(idx_other))*3600; 

    dy_Hdt(1:4) = Fg_out/V_G_H*(y_D(1:4)-y_H(1:4))*3600;
    dy_Hdt(idx_cons) =  y_H(idx_cons) - (1 - sum(y_H([1:4, idx_other])));
    dy_Hdt(idx_other) = Fg_out/V_G_H*(y_D(idx_other)-y_H(idx_other))*3600;

    if y_H(idx_other) > 1.1 || y_H(idx_cons) > 1.1
        a = 2;
    end
    % merge derivatives
    dcdt = [dcdt' ; dy_Ddt' ; dy_Hdt'];


    n_mt = [n_mt'./MW(1:4)*1000, 0, 0];                          % g/L/h --> mol/m3/h
    vol_rates = vol_rates_nec+vol_rates_cap;                     % g/L/h
    vol_rates_bal = vol_rates(1:4)./MW(1:4)'*1000;                % g/L/h --> mol/m3/h

end
