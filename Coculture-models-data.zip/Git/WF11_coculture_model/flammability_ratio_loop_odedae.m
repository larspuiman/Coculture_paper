%%
clear all
format compact
close all

%% Define gas ratios and gas mixes
O2_H2_ratio = 0.5;              % Base case for electrolysis = 1/2 --> more = add O2, less = add H2 from somewhere
H2_CH4_ratio = 6;              % Desired H2 to CH4 ratio
pure_o2 = 0;                    % use 1 if we use pure O2 (yO2 = 1, otherwise air)

%% define co_culture (2), Cn (0), or Mc (1) model
cc_spec = 2;


%% loop over various ratios for H2/CH4 and O2/H2
o2_h2_ratio = 0:0.5:10;
% o2_h2_ratio =  [0.55, 0.65];
% o2_h2_ratio = 6;
h2_ch4_ratio = 0:0.5:8;
% h2_ch4_ratio = 6;   
n_H2_ratios = length(h2_ch4_ratio);

%% define bioreactor operating conditions
params.Temp = 37+273.15;                     % K
params.Fg_in = 200*1e-6/60;                  % m3/s
params.rpm = 1400 * 1/60;                     % rpm --> 1/s
params.MW = [31.998, 2.016, 44.01, 16.042, 28.013, 40];    % Molecular mass [g/mol]
params.P_gas = 1.0 * 101325;                 % bar --> Pa
params.Dil = 1/24;                           % 1/h
params.kla_h2 = 423.11;                         % 1/h
params.kla_ch4 = 276.93;                         % 1/h
params.N_feed = 1.0;                         % g/L
geom.D = 0.094;                               % diameter [m]
geom.V_L = 1/1000;                           % volume [m3]
geom.V_R = 1.5/1000;                         % reactor volume [m3]
geom.D_imp = 0.0375;                   % impeller diameter;

params.ug_s = params.Fg_in/(1/4*pi*geom.D^2);                          % m/s

%% set initial conditions

% initial NH4, PHB and X concentration
c_NH4_ini = 1.0;                   % gram N in NH4
c_PHB_ini = 0;                     % 0 g/L
c_x_nec_ini = 0.03/0.3;            % inoculum in g/L
c_x_cap_ini = 0.03/0.3;            % inoculum in g/L

%% Prep for ODE-DAE solver
% time span
t0 = 0; dt = 1; t_end = 200;        % hour
t_span = t0:dt:t_end;               % time span in hour

% make mass matrix
n_liq = 8;                          % number of liquid conc
n_gas = 6;                          % number of gases to be modelled
n_x = 2;                            % number of biomasses (incl in n_liq)



%% Preallocate variables
vol_rates = zeros(length(h2_ch4_ratio), length(o2_h2_ratio), n_liq);
c_x_end = zeros(length(o2_h2_ratio), length(o2_h2_ratio), n_x);
conv = zeros(length(h2_ch4_ratio), length(o2_h2_ratio), n_gas);





disp("start looping");
for i = 1:n_H2_ratios
    for j = 1:length(o2_h2_ratio)
        
        
        %% calculate flammability of current gas composition
        H2_CH4_ratio = h2_ch4_ratio(i);
        O2_H2_ratio = o2_h2_ratio(j);

        fprintf("H2/CH4 = %f, O2/H2 = %f \n", H2_CH4_ratio, O2_H2_ratio)
        if H2_CH4_ratio > 2 && O2_H2_ratio > 2
            a = 2;
        end
        [flammable2(i,j), y_gas_in(i,j,:)] = flammability_limits_ratios(O2_H2_ratio, H2_CH4_ratio, pure_o2);
        
        %   CH4, H2, CO, O2, CO2, N2, Ar
        y_mix = [y_gas_in(i,j,2), y_gas_in(i,j,4), 0, y_gas_in(i,j,1), y_gas_in(i,j,3), y_gas_in(i,j,5), y_gas_in(i,j,6)];
        [flammable(i,j), LFL_mix(i,j), Sigma_tci(i,j)] = LFL_limit_gasferm(y_mix*100);


        %% use this as input gas composition

        y_in = squeeze(y_gas_in(i,j,:));
        y_h2 = y_in(4); y_ch4 = y_in(2);
        y_in(2) = y_h2; y_in(4) = y_ch4;
        params.y_in = y_in;
        
        % set initial values for ODE
        y_D = y_in;                  % gas fractions in dispersion [O2, H2, CO2, CH4]
        y_H = y_in;                  % gas fractions in headspace [O2, H2, CO2, CH4]
        c_sol = Henry(params.Temp)*params.P_gas.*y_in(1:4)';    % g/L for [O2, H2, CO2, CH4]
      
        % initial conc and gas fractions in g/L
        c_ini = [c_sol' ; c_NH4_ini ; c_PHB_ini ; c_x_nec_ini ; c_x_cap_ini ; y_D ; y_H];  

        %% make Mass matrix
        % baed on gas composition, if no N2, gas 6 is conserved, otherwise
        % Ar is conserved

        % N_algebraic_eqs = 2;                % for y_D and y_H
        % number of state variables
        ns = n_liq + 2*n_gas;

        M = zeros(ns,ns);                  % for all compounds
        for m = 1:ns
            M(m,m) = 1;                    % for the ODEs
            if (params.y_in(5) > 0)
                if (m == n_liq + n_gas-1) || (m == n_liq+n_gas*2-1)
                    M(m,m) = 0;                 % for the algebraic eqs in the gas phase
                end
            
            elseif (params.y_in(5) == 0) 
                if (m == n_liq + n_gas) || (m == n_liq+n_gas*2)
                M(m,m) = 0;                 % for the algebraic eqs in the gas phase
                end
            end
        end
        
        options = odeset('Mass', M, 'MassSingular', 'yes', 'RelTol', 1e-12, 'AbsTol', 1e-12);

        %% calculate CSTR results
        [time, c] = ode15s(@(t,y) str_fun_odedae(t, y, params, geom, cc_spec), t_span, c_ini, options);


        % get values at end of ODE
        [dcdt, Fg_out(i,j), vol_rates(i,j,:), n_mt(i,j,:)] = str_fun_odedae(time(end), c(end,:)', params, geom, cc_spec);
        conc(i,j,:) = c(end,:);
        y_D_end(i,j,:) = c(end,9:9+n_gas-1);
        y_H_end(i,j,:) = c(end,9+n_gas:9+n_gas*2-1);
    

%         cons_rates = vol_rates*geom.V_L/3600;     % mol/s
%         n_mt = n_mt*geom.V_L/3600;                % mol/s


        %%
    end
end

%% savedata
save("data_gascomp_ratios.mat",'Fg_out', 'vol_rates', 'n_mt', 'conc',"y_H_end", "y_D_end", "y_in", "params", "flammable", "LFL_mix", "Sigma_tci");

%% plot results
figure(1)
subplot(1,3,1)
s = contourf(o2_h2_ratio, h2_ch4_ratio, flammable);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% col = [252,141,89; 255,255,191; 145,191,219]/255;
% colormap(col);
grid on;
clim([0, 2]);
cbh = colorbar; 
cbh.Ticks = [0, 1, 2];
% set(cbh,'ticklabels', ({'< LFL', 'flammable, '> UFL'}));
set(gca,'fontsize', 16, 'fontname','times');
title('flammability limits with O_2')

subplot(1,3,2)
s = contourf(o2_h2_ratio, h2_ch4_ratio, LFL_mix);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
colormap("turbo");
grid on;
cbh = colorbar; 
% set(cbh,'ticklabels', ({'< LFL', 'flammable, '> UFL'}));
set(gca,'fontsize', 16, 'fontname','times');
title('LFL of gas mixture')

subplot(1,3,3)
s = contourf(o2_h2_ratio, h2_ch4_ratio, Sigma_tci);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
colormap("turbo");
grid on;
cbh = colorbar; 
% set(cbh,'ticklabels', ({'< LFL', 'flammable, '> UFL'}));
set(gca,'fontsize', 16, 'fontname','times');
title('\Sigma Tci of mixture')

% saveas(gcf,'Flammability_limits_air_zoom.png');


%%



%% plot results
% colormap("parula")
figure(3)
subplot(3,3,1)
clims = [min(conc(:,:,1),[],'all'), 1e-1];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,1)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('c_{O_2} (g/L)')
colorbar


subplot(3,3,2)
clims = [min(conc(:,:,2),[],'all'), 3e-3];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,2)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('c_{H_2} (g/L)')
colorbar

subplot(3,3,3)
clims = [min(conc(:,:,3),[],'all'), 1];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,3));hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('c_{CO_2} (g/L)')
colorbar

subplot(3,3,4)
clims = [min(conc(:,:,4),[],'all'), 2e-2];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,4)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('c_{CH_4} (g/L)')
colorbar

subplot(3,3,5)
clims = [min(conc(:,:,6)+conc(:,:,7),[],'all'), max(conc(:,:,6)+conc(:,:,7),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,6)+conc(:,:,7)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('Necator + PHB (g/L)')
colorbar

subplot(3,3,6)
clims = [min(conc(:,:,8),[],'all'), max(conc(:,:,8),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,8)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('Capsulatus (g/L)')
colorbar


% legend('O_2', 'CH_4', 'CO_2', 'H_2', 'N_2', 'Ar')

subplot(3,3,7)
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,1))); hold on;
original_caxis = clim();  
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
clim(original_caxis);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{O_2}')
colorbar


subplot(3,3,8)
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,2))); hold on;
original_caxis = clim();  
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
clim(original_caxis);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{CH_4}')
colorbar


subplot(3,3,9)
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,5))); hold on;
original_caxis = clim();  
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
clim(original_caxis);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{N_2}')
colorbar

set(gcf, 'Renderer', 'zbuffer');
set(gcf,'Position',[     -1959                     -37.4                    1513.6                     829.6]);
saveas(gcf,'y_var_air_CSTR_biogas_simple_D1_zoom.png')


%%

figure(4)
subplot(3,3,1)
clims = [min(y_H_end(:,:,1),[],'all'), max(y_H_end(:,:,1),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,1)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{O_2},out)')
colorbar


subplot(3,3,2)
clims = [min(y_H_end(:,:,2),[],'all'), max(y_H_end(:,:,2),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,2)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{CH_4} ')
colorbar

subplot(3,3,3)
clims = [min(y_H_end(:,:,3),[],'all'), max(y_H_end(:,:,3),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,3));hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{CO_2} ')
colorbar

subplot(3,3,4)
clims = [min(y_H_end(:,:,4),[],'all'), max(y_H_end(:,:,4),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,4)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{H_2}')
colorbar

subplot(3,3,5)
clims = [min(y_H_end(:,:,5),[],'all'), max(y_H_end(:,:,5),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,5)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{N_2}')
colorbar

subplot(3,3,6)
clims = [min(y_H_end(:,:,6),[],'all'), max(y_H_end(:,:,6),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,6)); hold on;

contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{Ar}')
colorbar


% legend('O_2', 'CH_4', 'CO_2', 'H_2', 'N_2', 'Ar')

subplot(3,3,7)
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,1))); hold on;
original_caxis = clim();  
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
clim(original_caxis);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{O_2}')
colorbar


subplot(3,3,8)
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,2))); hold on;
original_caxis = clim();  
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
clim(original_caxis);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{CH_4}')
colorbar


subplot(3,3,9)
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,5))); hold on;
original_caxis = clim();  
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
clim(original_caxis);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('y_{N_2}')
colorbar

set(gcf, 'Renderer', 'zbuffer');
set(gcf,'Position',[     -1959                     -37.4                    1513.6                     829.6]);
saveas(gcf,'y_gas_out.png')


%%
figure()
subplot(2,2,1)
clims = [min(conc(:,:,7)+conc(:,:,8),[],'all'), max(conc(:,:,7)+conc(:,:,8),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,7)+conc(:,:,8)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('Mt + Cn (g/L)')
colorbar

subplot(2,2,2)
clims = [0, 3];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,7)./conc(:,:,8)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('Cn/Mt')
colorbar


subplot(2,2,3)
clims = [-0.2, 0.2];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(vol_rates(:,:,3))); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, squeeze(vol_rates(:,:,3)), ...
         [0 0], 'k--', 'LineWidth', 1);
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('CO2 prod. rate (g/L/h)')
colorbar


subplot(2,2,4)
clims = [min(-vol_rates(:,:,4),[],'all'), max(-vol_rates(:,:,4),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, -squeeze(vol_rates(:,:,4))); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims);
ylabel("H_2 / CH_4 ratio"); 
xlabel("O_2 / H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', 12, 'fontname','times');
title('CH4 cons. rate (g/L/h)')
colorbar
set(gcf,'position',[488.0000  333.8000  709.0000  524.2000])
saveas(gcf,'Fig_paper_proposal.png')
%%


function f = fun_n2_frac(y_n2, F_N2, F_int, y_int, y_N2)
   
    % calculate N2 fraction in final gas
    f = y_n2 - (F_int*y_int(5) + F_N2*y_N2) / (F_int+F_N2);

end



function [flammable, y_mix] = flammability_limits_ratios(o2_h2, h2_ch4, pure_o2)

% Y_h2_biogas = gas_ratio(1);
% Y_o2_biogas = gas_ratio(2);



%% flammability limits
LFL_H2 = 4;
LFL_CH4 = 5;
UFL_H2 = 75;
UFL_CH4 = 61;
           
          % O2, CH4, CO2, H2, N2, Ar
LFL =      [0,  LFL_CH4, 0, LFL_H2, 0, 0];
UFL =      [0,  UFL_CH4, 0, UFL_H2, 0, 0];

%% composition of gases
y_biogas = [0, 0.54, 0.36, 0, 0, 0.1];
y_o2 =     [0.209476, 0, 0.0004, 0, 0.780784, 0.00934 ];
if pure_o2 == 1
    y_o2 =     [1, 0, 0, 0, 0, 0 ];
end
y_h2 =     [0, 0, 0, 1, 0, 0];

Y_h2_biogas = h2_ch4 * y_biogas(2);
Y_air_biogas = o2_h2 * Y_h2_biogas/y_o2(1);


%%  composition of gas mix
    % end-gas mix
mix_ratio = y_biogas + y_o2*Y_air_biogas + Y_h2_biogas*y_h2;
y_mix = mix_ratio./sum(mix_ratio);
    % the flammable gas mix
mix_flam_ratio = y_biogas + Y_h2_biogas*y_h2;
y_flam_mix = mix_flam_ratio./sum(mix_flam_ratio);


%% check flammability
LFL_term = y_flam_mix./LFL;
UFL_term = y_flam_mix./UFL;

LFL_mix = 1/sum(LFL_term(~isinf( LFL_term) ), 'omitnan');
UFL_mix = 1/sum(UFL_term(~isinf( UFL_term) ), 'omitnan' );

y_flammables = (y_mix(2) + y_mix(4))*100;

if y_flammables < LFL_mix
    flammable = 0;
elseif y_flammables > UFL_mix
    flammable = 2;
else
    flammable = 1;
end

end


