
function diff = diffusion(T,visc)
    % diffusion coefficient as function of temperature and viscosity
    if nargin < 2                   % if viscosity is not specified
        mu_T = viscosity(T);        % water visc @ T in [Pa.s]
    else
        mu_T = visc;                % specified visc
    end

    % constants at 25 degC O2, H2, CO2, CH4
    D_const = [2.10, 4.5, 1.92, 1.49]*1e-9;       % diffusion const @ 25deg m2/s
    T_ref = 25+273.15;                      % ref temperature K
    mu_25 = viscosity(T_ref);               % Pa.s
    mu_T = viscosity(T);                    % Pa.s

    % viscosity can be specified for viscous media
    if size(visc) > 0       
        mu_T = visc;
    end

    diff = D_const*T*mu_25/(mu_T*T_ref);    % m2/s
    
end