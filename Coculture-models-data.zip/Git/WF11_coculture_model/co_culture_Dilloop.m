%%
clear all
format compact
close all

%% Define gas ratios and gas mixes
O2_H2_ratio = 6;                % 6 Used in our experiment
H2_CH4_ratio = 2;               % 2 Used in our experiment
pure_o2 = 0;                    % use 1 if we use pure O2 (yO2 = 1, otherwise air)

%% define co_culture (2), Cn (0), or Mc (1) model
cc_spec = 2;

%% loop over various ratios for H2/CH4 and O2/H2
o2_h2_ratio = O2_H2_ratio;
h2_ch4_ratio = H2_CH4_ratio;

%% define bioreactor operating conditions

params.Temp = 37+273.15;                     % K
params.Fg_in = 200*1e-6/60;                  % m3/s
params.rpm = 1400 * 1/60;                     % rpm --> 1/s
params.MW = [31.998, 2.016, 44.01, 16.042, 28.013, 40];    % Molecular mass [g/mol]
params.P_gas = 1.0 * 101325;                 % bar --> Pa
params.kla_h2 = 423.11;                         % 1/h
params.kla_ch4 = 276.93;                         % 1/h
params.N_feed = 1.0;                         % g/L
geom.D = 0.094;                               % diameter [m]
geom.V_L = 1/1000;                           % volume [m3]
geom.V_R = 1.5/1000;                         % reactor volume [m3]
geom.D_imp = 0.0375;                   % impeller diameter;

params.ug_s = params.Fg_in/(1/4*pi*geom.D^2);                          % m/s

%% set initial conditions

% initial NH4, PHB and X concentration
c_NH4_ini = 1.0;                   % gram N in NH4
c_PHB_ini = 0;                     % 0 g/L
c_x_nec_ini = 0.03/0.3;            % inoculum in g/L
c_x_cap_ini = 0.03/0.3;            % inoculum in g/L

%% Prep for ODE-DAE solver
% time span
t0 = 0; dt = 1; t_end = 200;        % hour
t_span = t0:dt:t_end;               % time span in hour

% make mass matrix
n_liq = 8;                          % number of liquid conc
n_gas = 6;                          % number of gases to be modelled
n_x = 2;                            % number of biomasses (incl in n_liq)

       
%% calculate flammability of current gas composition
[~, y_gas_in] = flammability_limits_ratios(O2_H2_ratio, H2_CH4_ratio, pure_o2);

%   CH4, H2, CO, O2, CO2, N2, Ar
y_mix = [y_gas_in(2), y_gas_in(4), 0, y_gas_in(1), y_gas_in(3), y_gas_in(5), y_gas_in(6)];
[flammable, LFL_mix, Sigma_tci] = LFL_limit_gasferm(y_mix*100);

%% use this as input gas composition

y_in = y_gas_in(:);
y_h2 = y_in(4); y_ch4 = y_in(2);
y_in(2) = y_h2; y_in(4) = y_ch4;
params.y_in = y_in;

% set initial values for ODE
y_D = y_in;                  % gas fractions in dispersion [O2, H2, CO2, CH4]
y_H = y_in;                  % gas fractions in headspace [O2, H2, CO2, CH4]
c_sol = Henry(params.Temp)*params.P_gas.*y_in(1:4)';    % g/L for [O2, H2, CO2, CH4]

% initial conc and gas fractions in g/L
c_ini = [c_sol' ; c_NH4_ini ; c_PHB_ini ; c_x_nec_ini ; c_x_cap_ini ; y_D ; y_H];

%% make Mass matrix
% baed on gas composition, if no N2, gas 6 is conserved, otherwise
% Ar is conserved

% N_algebraic_eqs = 2;                % for y_D and y_H
% number of state variables
ns = n_liq + 2*n_gas;

M = zeros(ns,ns);                  % for all compounds
for m = 1:ns
    M(m,m) = 1;                    % for the ODEs
    if (params.y_in(5) > 0)
        if (m == n_liq + n_gas-1) || (m == n_liq+n_gas*2-1)
            M(m,m) = 0;                 % for the algebraic eqs in the gas phase
        end

    elseif (params.y_in(5) == 0)
        if (m == n_liq + n_gas) || (m == n_liq+n_gas*2)
            M(m,m) = 0;                 % for the algebraic eqs in the gas phase
        end
    end
end

options = odeset('Mass', M, 'MassSingular', 'yes', 'RelTol', 1e-12, 'AbsTol', 1e-12);


%% set Dilution values
D_start = 0;
D_end = 10;
dD = (D_end-D_start)/50;
Dil_vec = (D_start:dD:D_end);            % 1/d



%% Preallocate variables
vol_rates_bal = zeros(length(Dil_vec), 4);
c_x_end = zeros(length(Dil_vec), n_x);

%% loop over kla
for i = 1:length(Dil_vec)
    params.Dil = Dil_vec(i)/24;                                            % 1/h

    %% calculate CSTR results
    [time, c] = ode15s(@(t,y) str_fun_odedae(t, y, params, geom, cc_spec), t_span, c_ini, options);
    
    % get values at end of ODE
    [dcdt, Fg_out, ~, n_mt, vol_rates] = str_fun_odedae(time(end), c(end,:)', params, geom, cc_spec);
    
    % store variables we want
    c_x_end(i,:) = c(end,7:8);
    vol_rates_bal(i,:) = vol_rates'*24;
end


%% plot results
figure()
subplot(1,3,1)
plot(Dil_vec, sum(c_x_end,2), 'k-', 'linewidth',3); hold on;
xlabel('D (d^{-1})');
ylabel('c_x (g L^{-1})');
title("a) Biomass concentration");
set(gca, 'fontsize', 15);
set(gca, 'FontName', 'times');
plot([1, 1], [0, 25], 'k--');
grid on;

subplot(1,3,2)
plot(Dil_vec, c_x_end(:,1)./c_x_end(:,2), "Color", [202,255,202]/255, 'linewidth',3); hold on;
xlabel('D (d^{-1})');
ylabel('c_{x,\it{C. necator}}/c_{x,\it{M.capsulatus}}');
title("b) Ratio between species");
set(gca, 'fontsize', 15);
set(gca, 'FontName', 'times');
plot([1, 1], [0, 0.8], 'k--');
grid on;

subplot(1,3,3)
plot(Dil_vec, vol_rates_bal(:,2), "Color", [4,35,51]/255,  'linewidth',3); hold on;
plot(Dil_vec, vol_rates_bal(:,4), "Color", [64,52,159]/255, 'linewidth',3); hold on;
plot(Dil_vec, vol_rates_bal(:,1), "Color", [139,83,141]/255, 'linewidth',3); hold on;
plot(Dil_vec, vol_rates_bal(:,3), "Color", [214,108,108]/255,  'linewidth',3); hold on;
legend("H_2", "CH_4", "O_2", "CO_2", 'location', 'west');
plot([1, 1], [-300, 100], 'k--', 'HandleVisibility', 'off');
xlabel('D (d^{-1})');
ylabel('r_{i} (mmol L^{-1}d^{-1})');
title("c) Volumetric rates");
set(gca, 'fontsize', 15);
set(gca, 'FontName', 'times');
grid on;

set(gcf,'position', 1e3*[   -2.7918    0.2154    1.2360    0.4224]);
saveas(gcf,'Fig_dilution_rate.png')
saveas(gcf,'Fig_dilution_rate.svg')







function f = fun_n2_frac(y_n2, F_N2, F_int, y_int, y_N2)
   
    % calculate N2 fraction in final gas
    f = y_n2 - (F_int*y_int(5) + F_N2*y_N2) / (F_int+F_N2);

end



function [flammable, y_mix] = flammability_limits_ratios(o2_h2, h2_ch4, pure_o2)

% Y_h2_biogas = gas_ratio(1);
% Y_o2_biogas = gas_ratio(2);



%% flammability limits
LFL_H2 = 4;
LFL_CH4 = 5;
UFL_H2 = 75;
UFL_CH4 = 61;
           
          % O2, CH4, CO2, H2, N2, Ar
LFL =      [0,  LFL_CH4, 0, LFL_H2, 0, 0];
UFL =      [0,  UFL_CH4, 0, UFL_H2, 0, 0];

%% composition of gases
y_biogas = [0, 0.54, 0.36, 0, 0, 0.1];
y_o2 =     [0.209476, 0, 0.0004, 0, 0.780784, 0.00934 ];
if pure_o2 == 1
    y_o2 =     [1, 0, 0, 0, 0, 0 ];
end
y_h2 =     [0, 0, 0, 1, 0, 0];

Y_h2_biogas = h2_ch4 * y_biogas(2);
Y_air_biogas = o2_h2 * Y_h2_biogas/y_o2(1);


%%  composition of gas mix
    % end-gas mix
mix_ratio = y_biogas + y_o2*Y_air_biogas + Y_h2_biogas*y_h2;
y_mix = mix_ratio./sum(mix_ratio);
    % the flammable gas mix
mix_flam_ratio = y_biogas + Y_h2_biogas*y_h2;
y_flam_mix = mix_flam_ratio./sum(mix_flam_ratio);


%% check flammability
LFL_term = y_flam_mix./LFL;
UFL_term = y_flam_mix./UFL;

LFL_mix = 1/sum(LFL_term(~isinf( LFL_term) ), 'omitnan');
UFL_mix = 1/sum(UFL_term(~isinf( UFL_term) ), 'omitnan' );

y_flammables = (y_mix(2) + y_mix(4))*100;

if y_flammables < LFL_mix
    flammable = 0;
elseif y_flammables > UFL_mix
    flammable = 2;
else
    flammable = 1;
end

end


