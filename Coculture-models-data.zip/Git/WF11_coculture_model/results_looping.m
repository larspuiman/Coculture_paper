%%
clear all
format compact
close all

%% load data
load("data_gascomp_ratios_parloop.mat")

%% modify data

MW = reshape(params.MW(1:4), 1, 1, []);
vol_rates = vol_rates(:,:,1:4)./MW*1000*24;                % g/L/h --> mol/m3/d
n_gas_in = params.Fg_in * y_gas_in * params.P_gas / (8.314*params.Temp) * 3600*24 * 1000;    % mmol/L/d
n_gas_out = Fg_out .* y_H_end * params.P_gas / (8.314*params.Temp) * 3600*24 * 1000;    % mmol/L/d

conv = 100 - (n_gas_in(:,:,1:4) + vol_rates)./n_gas_in(:,:,1:4) * 100;
conv = -vol_rates./n_gas_in(:,:,1:4) * 100; 
C_conv = ( sum(n_gas_in(:,:,3:4),3) - sum(n_gas_out(:,:,3:4),3) )./ sum(n_gas_in(:,:,3:4),3) * 100 ;
CO2_conv = ( n_gas_in(:,:,3) - n_gas_out(:,:,3) )./ n_gas_in(:,:,3) * 100 ;
CH4_conv = ( n_gas_in(:,:,4) - n_gas_out(:,:,4) )./ n_gas_in(:,:,4) * 100 ;


o2_h2_ratio = o2_h2_ratio/0.21;
h2_ch4_ratio = h2_ch4_ratio*0.54;

letter_font_size = 14;

exp_x = 28.5;
exp_y = 1.08;

% %% plot results
% 
% % colormap("parula")
% figure(3)
% subplot(3,3,1)
% % clims = [min(conc(:,:,1),[],'all'), 1e-1];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(n_gas_in(:,:,1))); hold on;
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% % clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('O2 in mmol/L/d')
% colorbar
% 
% 
% subplot(3,3,2)
% % clims = [min(conc(:,:,2),[],'all'), 3e-3];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(n_gas_in(:,:,2))); hold on;
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% % clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('H2 in mmol/L/d')
% colorbar
% 
% subplot(3,3,3)
% % clims = [min(conc(:,:,3),[],'all'), 1];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(n_gas_in(:,:,3))); hold on;
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% % % clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('CO2 in mmol/L/d')
% colorbar
% 
% subplot(3,3,4)
% % clims = [min(conc(:,:,4),[],'all'), 2e-2];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(n_gas_in(:,:,4))); hold on;
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% % clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('CH4 in mmol/L/d')
% colorbar
% 
% subplot(3,3,5)
% % clims = [min(conc(:,:,4),[],'all'), 2e-2];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_H_end(:,:,3))); hold on;
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% % clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('CO2 out mmol/L/d')
% colorbar
% 
% subplot(3,3,6)
% % clims = [min(conc(:,:,8),[],'all'), max(conc(:,:,8),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(n_gas_out(:,:,4))); hold on;
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% % contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% % clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('CH4 out mmol/L/d')
% colorbar
% 
% 
% % legend('O_2', 'CH_4', 'CO_2', 'H_2', 'N_2', 'Ar')
% 
% subplot(3,3,7)
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_H_end(:,:,3))); hold on;
% original_caxis = clim();  
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
% clim(original_caxis);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{CO_2, out}')
% colorbar
% 
% 
% subplot(3,3,8)
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_H_end(:,:,4))); hold on;
% original_caxis = clim();  
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
% clim(original_caxis);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{CH_4,out}')
% colorbar
% 
% 
% subplot(3,3,9)
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,5))); hold on;
% original_caxis = clim();  
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
% clim(original_caxis);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{N_2}')
% colorbar
% 
% set(gcf, 'Renderer', 'zbuffer');
% set(gcf,'Position',[     -1959                     -37.4                    1513.6                     829.6]);
% saveas(gcf,'y_var_air_CSTR_biogas_simple_D1_zoom.png')
% 
% 
% %%
% 
% figure(4)
% subplot(3,3,1)
% clims = [min(y_H_end(:,:,1),[],'all'), max(y_H_end(:,:,1),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,1)); hold on;
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{O_2},out)')
% colorbar
% 
% 
% subplot(3,3,2)
% clims = [min(y_H_end(:,:,2),[],'all'), max(y_H_end(:,:,2),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,2)); hold on;
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{CH_4} ')
% colorbar
% 
% subplot(3,3,3)
% clims = [min(y_H_end(:,:,3),[],'all'), max(y_H_end(:,:,3),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,3));hold on;
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{CO_2} ')
% colorbar
% 
% subplot(3,3,4)
% clims = [min(y_H_end(:,:,4),[],'all'), max(y_H_end(:,:,4),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,4)); hold on;
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{H_2}')
% colorbar
% 
% subplot(3,3,5)
% clims = [min(y_H_end(:,:,5),[],'all'), max(y_H_end(:,:,5),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,5)); hold on;
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{N_2}')
% colorbar
% 
% subplot(3,3,6)
% clims = [min(y_H_end(:,:,6),[],'all'), max(y_H_end(:,:,6),[],'all')];  % Individual scaling for each plot]
% s = surf(o2_h2_ratio, h2_ch4_ratio, y_H_end(:,:,6)); hold on;
% 
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
% clim(clims);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{Ar}')
% colorbar
% 
% 
% % legend('O_2', 'CH_4', 'CO_2', 'H_2', 'N_2', 'Ar')
% 
% subplot(3,3,7)
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,1))); hold on;
% original_caxis = clim();  
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
% clim(original_caxis);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{O_2}')
% colorbar
% 
% 
% subplot(3,3,8)
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,2))); hold on;
% original_caxis = clim();  
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
% clim(original_caxis);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{CH_4}')
% colorbar
% 
% 
% subplot(3,3,9)
% s = surf(o2_h2_ratio, h2_ch4_ratio, squeeze(y_gas_in(:,:,5))); hold on;
% original_caxis = clim();  
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [1 1], 'r', 'LineWidth', 2); % Red for LFL
% contour3(o2_h2_ratio, h2_ch4_ratio, flammable, [2 2], 'w', 'LineWidth', 2); % White for UFL
% clim(original_caxis);
% ylabel("H_2 / Biogas ratio"); 
% xlabel("Air / H_2 ratio")
% set(gca,'view', [ -0.8138   90.0000]);
% s.EdgeColor =  'none';
% set(gca,'fontsize', 12, 'fontname','times');
% title('y_{N_2}')
% colorbar
% 
% set(gcf, 'Renderer', 'zbuffer');
% set(gcf,'Position',[     -1959                     -37.4                    1513.6                     829.6]);
% saveas(gcf,'y_gas_out.png')


%%
letter_font_size = 14;
fontsize = 14;
figure()
colormap(cmocean('thermal'))

subplot(3,3,1)
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,8)); hold on;
clim([0, 15]); clims = clim();
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2 ratio")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('c_{x,Mc} (g L^{-1})')
colorbar
figLetter(gca, 'a)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');

subplot(3,3,2)
clim([0, 15]);
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,7)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim([0, 15]);
ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('c_{x,Cn} (g L^{-1})')
colorbar
figLetter(gca, 'b)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');

subplot(3,3,3)
clims = [min(conc(:,:,7)+conc(:,:,8),[],'all'), max(conc(:,:,7)+conc(:,:,8),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, conc(:,:,7)+conc(:,:,8)); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim([0, 15]);
ylim([0, 5]);

ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('c_{x,Mc} + c_{x,Cn} (g L^{-1})')
colorbar
figLetter(gca, 'c)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');


subplot(3,3,4)
clims = [-1*max(vol_rates(:,:,4),[],'all'), -1*min(vol_rates(:,:,4),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, -1*squeeze(vol_rates(:,:,4))); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims); ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('-r_{CH_4} (mmol L^{-1} d^{-1})')
colorbar
set(gcf,'position',[488.0000  333.8000  709.0000  524.2000])
figLetter(gca, 'd)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');


subplot(3,3,5)
clims = [-1*max(-vol_rates(:,:,3),[],'all'), -1*min(-vol_rates(:,:,3),[],'all')];  % Individual scaling for each plot]
s = surf(o2_h2_ratio, h2_ch4_ratio, -1*squeeze(vol_rates(:,:,3))); hold on;
contour3(o2_h2_ratio, h2_ch4_ratio, squeeze(vol_rates(:,:,3)), ...
         [0 0], 'k--', 'LineWidth', 1);
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims); ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('-r_{CO_2} (mmol L^{-1} d^{-1})')
colorbar
figLetter(gca, 'e)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');

subplot(3,3,6)
clims = [ 0, 600];  % Individual scaling for each plot]
s = surf( o2_h2_ratio, h2_ch4_ratio, -1*(squeeze(vol_rates(:,:,3)) + squeeze(vol_rates(:,:,4))) ); hold on;
contour3( o2_h2_ratio, h2_ch4_ratio, -1*(squeeze(vol_rates(:,:,3)) + squeeze(vol_rates(:,:,4))), ...
         [0 0], 'k--', 'LineWidth', 1);
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims); ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('-(r_{CO_2} + r_{CH_4}) (mmol L^{-1} d^{-1})')
colorbar
figLetter(gca, 'f)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');


subplot(3,3,7)
clims = [ 0, 100];  % Individual scaling for each plot]
s = surf( o2_h2_ratio, h2_ch4_ratio, squeeze(conv(:,:,4)) ); hold on;
contour3( o2_h2_ratio, h2_ch4_ratio, squeeze(conv(:,:,4)) , ...
         [0 0], 'k--', 'LineWidth', 1);
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims); ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('-r_{CH_4}/ṅ_{CH_4,in} (%)')
colorbar
figLetter(gca, 'g)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');

subplot(3,3,8)
clims = [ -100, 150];  % Individual scaling for each plot]
s = surf( o2_h2_ratio, h2_ch4_ratio, squeeze(conv(:,:,3)) ); hold on;
contour3( o2_h2_ratio, h2_ch4_ratio, squeeze(conv(:,:,3)) , ...
         [0 0], 'k--', 'LineWidth', 1);
contour3( o2_h2_ratio, h2_ch4_ratio, squeeze(conv(:,:,3)) , ...
         [100 100], 'k:', 'LineWidth', 1);

contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL (value 1)
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL (value 2)
clim(clims); ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('-r_{CO_2}/ṅ_{CO_2,in} (%)')
colorbar
figLetter(gca, 'h)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');

subplot(3,3,9)
clims = [ 0, 100];  % Individual scaling for each plot]
s = surf( o2_h2_ratio, h2_ch4_ratio, squeeze(C_conv) ); hold on;
contour3( o2_h2_ratio, h2_ch4_ratio, squeeze(C_conv) , ...
         [0 0], 'k--', 'LineWidth', 1);
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [1+clims(2) 1+clims(2)], 'r', 'LineWidth', 2); % Red for LFL
contour3(o2_h2_ratio, h2_ch4_ratio, flammable+clims(2), [2+clims(2) 2+clims(2)], 'w', 'LineWidth', 2); % White for UFL
clim(clims); ylim([0, 5]);
ylabel("H_2/Biogas"); 
xlabel("Air/H_2")
set(gca,'view', [ -0.8138   90.0000]);
s.EdgeColor =  'none';
set(gca,'fontsize', fontsize, 'fontname','times');
title('-(r_{CO_2}+r_{CH_4})/(ṅ_{CO_2,in}+ṅ_{CH_4,in}) (%)')
colorbar
figLetter(gca, 'i)', letter_font_size);
m = plot3(exp_x, exp_y, clims(2) + 3, '^', 'MarkerSize', 8, 'MarkerEdgeColor','k');


set(gcf,'position', 1e3*[    0.0010    0.0490    1.5360    0.8368])
saveas(gcf,'Fig_paper_model_9subplot.png')
saveas(gcf,'Fig_paper_model_9subplot.svg')
%%


function f = figLetter(axis, string, size)

    xL = axis.XLim; yL = axis.YLim;
    xOffset = xL(1) - 0.15*(xL(2)-xL(1));   % push left, outside the axes
    f = text(-0.1, 1.1, string, 'Units', 'normalized', ...
    'FontName', 'Times', 'FontSize', size, 'FontWeight', 'bold', ...
    'Color', 'k', 'HorizontalAlignment','right', 'VerticalAlignment','top', ...
    'Clipping','off');

end