function H_temp = Henry(T) 
    % Henry const   O2,   H2,       CO2,   CH4 
    H_ref = [4.16e-07, 1.57E-08, 1.50E-05, 2.25E-07];       % Henry @ reference temp [g/L/Pa]
    T_ref = 298.15;                                         % K
    H_Tvar = [1500, 530, 2300, 1600];                       % Henry temperature var const [1/K] -d_solH/R = dH/d(1/T)
    % Temperature in Kelvin
    
    % calculate Henry @ temperature
    H_temp = H_ref .* exp(H_Tvar * (1/T - 1/T_ref));

end
