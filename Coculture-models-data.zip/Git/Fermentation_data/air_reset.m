close all
clear all
format compact


%% read data
path = cd;

reactor = [6,8];
time_start = 180;
time_end = 300;

%% Get TJx Run files
raw_data_folder = 'data';
% load xls with Growth samples and dilution rates
file_name_excel = "WF11_dataCollection";
file_path = append(path, '\',raw_data_folder,'\', file_name_excel);

data = readtable(file_path, 'Sheet', 3);
data = data{:,:};
t_OD = data(:,1);                   % h
OD_data = data(1:length(t_OD),1+reactor);              % OD
% Dil_data = data(1:length(t_OD),10:17)/24;        % 1/h

time = t_OD((t_OD > time_start) & (t_OD < time_end));
time_idx = find((t_OD > time_start) & (t_OD < time_end));

% get averages and STDEV
OD_av = mean(OD_data(time_idx),2);
OD_std = std(OD_data(time_idx),0,2);

% air stop bounds
t_start_R6 = 256.244;
t_end_R6 = 261.5;
t_start_R8 = 209.009;
t_end_R8 = 219.5;
air_stop_lims = [[t_start_R6, t_end_R6]; [t_start_R8, t_end_R8 ]];

%% Get rates data
for R = 1:length(reactor)
    raw_data_folder = 'results';
    % load xls with Growth samples and dilution rates
    file_name_excel = ['R0' num2str(reactor(R)) '_processed_data_update.csv'];
    file_path = append(path, '\',raw_data_folder,'\', file_name_excel);
    data = readtable(file_path);
    %%
    % data = data{:,:};
    runtime = data{:,1};                        % h
    rates_time_idx = find((runtime > time_start) & (runtime < time_end));
    time_air_reset = runtime(rates_time_idx);
    r_rates_temp = data{rates_time_idx,10:17};                      % mmol/L/d
    q_rates_temp = data{rates_time_idx,18:25};                      % mmol/L/d
    Fgas_in = data{rates_time_idx,26};
    y_gas_in(R,:,:) = data{rates_time_idx,27:33};
    F_gases_in = Fgas_in .* y_gas_in(R,:,:);
    cx = data{rates_time_idx, 3};
    OD = data{rates_time_idx, 2};
    mu(R,:) = data{rates_time_idx,5};
    
    y_gas_out(R,:,:) = data{rates_time_idx,35:41};
    
    
    
    for i = 1:length(time_air_reset)
        if (time_air_reset(i) >= air_stop_lims(R,1) && time_air_reset(i) <= air_stop_lims(R,2)) 
            r_rates(R,i,:) = 0;
            q_rates(R,i,:) = 0;
        else
            r_rates(R,i,:) = r_rates_temp(i,:);
            q_rates(R,i,:) = q_rates_temp(i,:);
        end
    end
end

%% calculate q-rates
 % assume: all H2 by cN, all CH4 by Mc
    % use stoichiometry from the excel sheet
    % cN: H2/x = -5.4. Mc: CH4/x = -1.92
% 
% rx_nec_exp = rates(:,1)/-5.4;  rx_nec_exp(rx_nec_exp<0) = 0 ;
% rx_ch4_exp = rates(:,3)/-1.92; rx_ch4_exp(rx_ch4_exp<0) = 0 ;
% 
% fracs = [rx_nec_exp./(rx_nec_exp+rx_ch4_exp), rx_ch4_exp./(rx_nec_exp+rx_ch4_exp)]*100;       % frac CN, frac Mc
% cx_Cn = cx.*fracs(:,1)/100;
% cx_Mc = cx.*fracs(:,2)/100;
% 
% r_Mc = rates(:,3)*[0, 0, 1, 0, 0.6878, 0,	-0.3301	-0.3576];
% r_Cn = rates(:,1)*[1, 0, 0, 0, 0.2907, 0,	0.6586	-0.6441];
% 
% q_Mc = r_Mc./cx_Mc;
% q_Cn = r_Cn./cx_Cn;

%%

%% make graph of batch averages
cmp_idx = [1,5,7,8];
compounds_mu = {'H_2', 'O_2', 'CO_2', '\mu'};
letter_font_size = 15;

figure()
subplot(2,3,1)
% yyaxis left
plot(t_OD, OD_data(:,1), '-.o', 'color', [0.5,0.5,0.5], 'LineWidth', 1); hold on;
plot(t_OD, OD_data(:,2), 'k-.o', 'LineWidth', 1); hold on;
xlabel("time (h)"); ylabel("OD_{600}");
xlim([time_start, time_end]); grid on;
% Lock the y-limits BEFORE drawing patches, so patches don't rescale the axis
ylim([0 7]);          % or whatever range you want
set(gca,'YLimMode','manual');
set(gca, 'fontname','times')
set(gca, 'fontsize',14)
legend('R06', 'R08', 'location', 'west', 'fontsize', 12);
figLetter(gca, 'a)', letter_font_size)
boxR6 = patch([t_start_R6, t_end_R6, t_end_R6, t_start_R6], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                          [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R6, t_end_R6]),gca().YLim(2)*0.10, 'R6', ...
    'Rotation', 90, 'HorizontalAlignment','right', 'Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');

boxR8 = patch([t_start_R8, t_end_R8, t_end_R8, t_start_R8], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                          [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R8, t_end_R8]), gca().YLim(2)*0.10, 'R8', ...
    'Rotation', 90, 'HorizontalAlignment','right','Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');

% arrows
t_arrow = [252.3, 252.3];
y_arrow = [6.4, 5.9];
text_arrow = '0.5 d^{-1}';
font_size = 14;
font_name = 'Times';

arrowtext(gca(), t_arrow, y_arrow, text_arrow, font_size, font_name)

% arrows
t_arrow = [235.7, 235.7];
y_arrow = [3.9+0.5, 3.9];
text_arrow = '0.25 d^{-1}';
arrowtext(gca(), t_arrow, y_arrow, text_arrow, font_size, font_name)

t_arrow = [276.6, 276.6];
y_arrow = [6.35+0.5, 6.35];
text_arrow = ' ';
arrowtext(gca(), t_arrow, y_arrow, text_arrow, font_size, font_name)

% Text placed manually in DATA coordinates, to the right of the tail
text(gca(), 279, 6.7, '1 d^{-1}', ...
    'Color', 'k', 'FontName','Times','FontSize',font_size, ...
    'HorizontalAlignment','left', 'VerticalAlignment','middle');

t_arrow = [276.6, 276.6];
y_arrow = [3.0+0.5, 3.0];
text_arrow = '0.25 d^{-1}';
arrowtext(gca(), t_arrow, y_arrow, text_arrow, font_size, font_name)



% gas uptake rates
subplot(2,3,2)
[a_p, a_n] = area_graph(time_air_reset, squeeze(r_rates(1,:,cmp_idx)), compounds_mu, 0);
xlabel('time (h)'); 
ylabel('r_i (mmol_i L^{-1}d^{-1})')
ylim([-600, 100]); set(gca,'YLimMode','manual');
% xlim([240, 280]);
xlim([time_start, time_end]); grid on;
set(gca, 'fontname','times')
set(gca, 'fontsize',14)
legend('H_2', 'O_2', 'CO_2', 'Growth', 'location', 'southwest', 'fontsize', 10)
figLetter(gca, 'b)', letter_font_size)
boxR6 = patch([t_start_R6, t_end_R6, t_end_R6, t_start_R6], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                          [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R6, t_end_R6]), (gca().YLim(2)-gca().YLim(1))*0.10+gca().YLim(1), 'R6', ...
    'Rotation', 90, 'HorizontalAlignment','right', 'Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');

% gas uptake rates
subplot(2,3,3)
[a_p, a_n] = area_graph(time_air_reset, squeeze(q_rates(1,:,cmp_idx)), compounds_mu, 0);
xlabel('time (h)'); 
ylabel('q_i (mmol_i g_{CDW}^{-1}d^{-1})')
ylim([-500, 100]);set(gca,'YLimMode','manual');

% xlim([240, 280]);
xlim([time_start, time_end]); grid on;
set(gca, 'fontname','times')
set(gca, 'fontsize',14)
figLetter(gca, 'c)', letter_font_size)
boxR6 = patch([t_start_R6, t_end_R6, t_end_R6, t_start_R6], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                         [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R6, t_end_R6]), (gca().YLim(2)-gca().YLim(1))*0.10+gca().YLim(1), 'R6', ...
    'Rotation', 90, 'HorizontalAlignment','right', 'Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');

cmp = [166,206,227;
31,120,180;
178,223,138;
51,160,44]/255;

subplot(2,3,4)
plot(time_air_reset, y_gas_in(1,:,7), '-', 'color', cmp(3,:), 'LineWidth', 3); hold on;
plot(time_air_reset, y_gas_in(1,:,1), '-', 'color', cmp(1,:), 'LineWidth', 3); hold on;
plot(time_air_reset, y_gas_in(1,:,5), '-', 'color', cmp(2,:), 'LineWidth', 3); hold on;
plot(time_air_reset, y_gas_in(1,:,3), '-', 'color', 'm', 'LineWidth', 1); hold on;
plot(time_air_reset, y_gas_in(1,:,4), '-', 'color', 'k', 'LineWidth', 1); hold on;
xlabel("time (h)"); ylabel("y_{in}");
ylim([0, 0.8]);set(gca,'YLimMode','manual');

xlim([248, 265]); grid on;
set(gca, 'fontname','times')
set(gca, 'fontsize',14)
legend('CO_2', 'H_2', 'O_2', 'CH_4', 'N_2', 'location', 'northwest', 'fontsize', 10)
figLetter(gca, 'd)', letter_font_size)
boxR6 = patch([t_start_R6, 257.5, 257.5, t_start_R6], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                          [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R6, 257]), (gca().YLim(2)-gca().YLim(1))*0.10+gca().YLim(1), 'R6', ...
    'Rotation', 90, 'HorizontalAlignment','right', 'Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');


% gas uptake rates
subplot(2,3,5)
[a_p, a_n] = area_graph(time_air_reset, squeeze(r_rates(2,:,cmp_idx)), compounds_mu, 0);
xlabel('time (h)'); 
ylabel('r_i (mmol_i L^{-1}d^{-1})')
ylim([-600, 100]); 
xlim([time_start, time_end]); grid on;
set(gca, 'fontname','times')
set(gca, 'fontsize',14)
figLetter(gca, 'e)', letter_font_size)
boxR8 = patch([t_start_R8, t_end_R8, t_end_R8, t_start_R8], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                         [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R8, t_end_R8]),  (gca().YLim(2)-gca().YLim(1))*0.10+gca().YLim(1), 'R8', ...
    'Rotation', 90, 'HorizontalAlignment','right','Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');

% gas uptake rates
subplot(2,3,6)
[a_p, a_n] = area_graph(time_air_reset, squeeze(q_rates(2,:,cmp_idx)), compounds_mu, 0);
xlabel('time (h)'); 
ylabel('q_i (mmol_i g_{CDW}^{-1}d^{-1})')
ylim([-500, 100]);
xlim([time_start, time_end]); grid on;
set(gca, 'fontname','times')
set(gca, 'fontsize',14)
figLetter(gca, 'f)', letter_font_size)
boxR8 = patch([t_start_R8, t_end_R8, t_end_R8, t_start_R8], [gca().YLim(1), gca().YLim(1), gca().YLim(2), gca().YLim(2)], ...
                         [0.85 0.33 0.10], 'EdgeColor','k', 'FaceAlpha', 0.25, 'HandleVisibility','off');
text(gca, mean([t_start_R8, t_end_R8]), (gca().YLim(2)-gca().YLim(1))*0.10+gca().YLim(1), 'R8', ...
    'Rotation', 90, 'HorizontalAlignment','right','Fontname', 'times', ...
    'FontSize', 12, 'Color', 'k', 'FontWeight','bold');


set(gcf,'position',1e3*[     0.0010    0.0490    1.5360    0.8368]);



saveas(gcf,'fig_air_reset.png')
saveas(gcf,'fig_air_reset.svg')




function [a_p, a_n] = area_graph(time, data_s, compounds, error_check)


% set up data matrices that are postive and negative
data_pos = zeros(size(data_s));
data_neg = zeros(size(data_s));

% for each compound, find positive and negative data points
for cmpd = 1:size(data_s,2)
    % search for negative and positive data sets
    ind_data_neg = find(data_s(:,cmpd) < 0);
    ind_data_pos = find(data_s(:,cmpd) > 0);
    
    % put that data in our empty matrix. If there is none, it remains zeros.
    data_neg(ind_data_neg, cmpd) = data_s(ind_data_neg,cmpd);
    data_pos(ind_data_pos, cmpd) = data_s(ind_data_pos,cmpd);
end

% calculate mass balance error
if error_check == 1
    error = sum(data_pos,2) - abs(sum(data_neg,2));
    ind_error_neg = find(error > 0);
    ind_error_pos = find(error < 0);
    error_pos = zeros(size(error));  error_neg = zeros(size(error)); 
    error_pos(ind_error_pos) = abs(error(ind_error_pos)); 
    error_neg(ind_error_neg) = abs(error(ind_error_neg)); 
    
    compounds{end+1} = 'error';
    data_pos = [data_pos, error_pos];
    data_neg = [data_neg, -1*error_neg];
end

% make area graph for the mass balance
a_p = area( time , data_pos ); hold on;
a_n = area( time , data_neg ); hold on;

cmp = [166,206,227;
31,120,180;
178,223,138;
51,160,44]/255;

% cmp = parula(size(data_s,2)+1);
% cmp(end,:) = [1,0,0];

if error_check == 0
    for cmpd = 1:size(data_s,2)
        a_p(cmpd).FaceColor = cmp(cmpd,:);
        a_p(cmpd).LineWidth = 0.00000001;
        
        a_n(cmpd).FaceColor = cmp(cmpd,:);
        a_n(cmpd).LineWidth = 0.00000001;
    end
else
    for cmpd = 1:size(data_s,2)+1
        a_p(cmpd).FaceColor = cmp(cmpd,:);
        a_p(cmpd).LineWidth = 0.00000001;
        
        a_n(cmpd).FaceColor = cmp(cmpd,:);
        a_n(cmpd).LineWidth = 0.00000001;
    end
end


% legend(a_p,compounds,'location','bestoutside'); grid on;

end


function f = figLetter(axis, string, size)

    xL = axis.XLim; yL = axis.YLim;
    xOffset = xL(1) - 0.15*(xL(2)-xL(1));   % push left, outside the axes
    f = text(xOffset, yL(2), string, ...
    'FontName', 'Times', 'FontSize', size, 'FontWeight', 'bold', ...
    'Color', 'k', 'HorizontalAlignment','right', 'VerticalAlignment','top', ...
    'Clipping','off');

end

function t = arrowtext(ax, t_arrow, y_arrow, text, font_size, font_name)

    
    % Get axes position in normalized figure units
    axPos = ax.Position;      % [left bottom width height]
    xLim = ax.XLim;
    yLim = ax.YLim;
    
    % Map data coords -> normalized figure coords
    t_arrow_tip = t_arrow(1); t_arrow_tail = t_arrow(2);
    y_arrow_tip = y_arrow(1); y_arrow_tail = y_arrow(2);
    
    x_norm = axPos(1) + ([t_arrow_tip t_arrow_tail]  - xLim(1))/(xLim(2)-xLim(1)) * axPos(3);
    y_norm = axPos(2) + ([y_arrow_tip y_arrow_tail] - yLim(1))/(yLim(2)-yLim(1)) * axPos(4);
    
    t = annotation('textarrow', x_norm, y_norm, ...
        'String', text, ...
        'Color', 'k', ...        % yellow arrow/text
        'TextColor', 'k', ...
        'FontName', font_name, ...
        'FontSize', font_size, ...
        'HeadStyle', 'vback2', ...
        'LineWidth', 3);
end