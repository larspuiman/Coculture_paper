close all
clear all
format compact

%% read data
path = cd;

% Get TJx Run files
raw_data_folder = 'data';
unix_pattern = fullfile(raw_data_folder, '*Run*.csv');
% Get the list of files matching the pattern within the folder
file_list = dir(unix_pattern);
n_files = length(file_list);

% load xls with Growth samples and dilution rates
file_name_excel = "WF11_dataCollection";
file_path = append(path, '\',raw_data_folder,'\', file_name_excel);

data = readtable(file_path, 'Sheet', 3);
data = data{:,:};
t_OD = data(:,1);                   % h
OD_data = data(1:length(t_OD),2:9);              % OD
Dil_data = data(1:length(t_OD),10:17)/24;        % 1/h
gL_OD = 0.32;                                            % g/L/OD

% if you want to select a specific range - use index value = row value in
% Excel
% data_start = 684;
% data_end = []; %92114
time_start = [];
time_end = [];

% store the results ? 1 = yes, 0 = no
store_results = 1;
plot_average_graph = 0;

if store_results == 1
    mkdir results
    results_folder = 'results\';
end


% set up MFC allocation  --> use variable names from excel
air_MFC_PV = 'AirPV';  air_MFC_SP = 'AirSP';
CO2_MFC_PV = 'COPV';   CO2_MFC_SP = 'COSP';
H2_MFC_PV = 'H2PV';    H2_MFC_SP = 'H2SP';
MFC_head = {air_MFC_PV, air_MFC_SP, CO2_MFC_PV, CO2_MFC_SP, H2_MFC_PV, H2_MFC_SP};

% get MFC correction factors
file_path = append(path, '\',raw_data_folder,'\', file_name_excel);
data_mfc = readtable(file_path, 'Sheet', 'mfc_correction_fact');
data_mfc = data_mfc{:,2:end};

% set compositions of the used gas mixtures --> use MS order
%           [H2, H2O, CH4, N2, O2, Ar, CO2]
num_gases = 7;
compounds = {'H_2', 'H_2O', 'CH_4',   'N_2', 'O_2', 'Ar', 'CO_2'};
MW =        [2.016,  18.01528, 16.04, 28.0134, 31.998, 39.948, 44.01,24.6 ];    % Molecular mass [g/mol]
idx_gas_cons = 4;       % use N2 to converse gases

% provide composition of gases
y_air =     [0,  0,    0, 78.0784, 20.9476, 0.934, 0.04]/100;
y_h2 =      [1,  0,    0,    0,    0,     0,   0];
y_biogas =  [0,  0,   0.54,  0,    0,    0.1, 0.36];


% q-rate cap
        %  [H2,  H2O,  CH4,   N2,   O2,   Ar,    CO2]
q_mins =   [-50,  -2,   -50  -2,   -50,   -2,   -50];       % mmol/gx/h
q_max =    [2,    2,     2,   2,    2,     2,     60];                   % mmol/gx/h
r_mins =   [-500, -50, -250, -50, -350,  -50,  -100];       % mmol/gx/h
r_max =    [200,  100,  100,  100,  100,  100,   250];                   % mmol/gx/h

% MFC gas shift time if we changed gas lines to the MFCs
MFC_gas_shift_time = [];
MFC_gas_shift_reactors = [];

% SET UP THE CAL-GAS vector
% Get the calgas flows and timings from the table
gas_shift = 1;
data_calgas = readtable(file_path, 'Sheet', 'calgas');
data_calgas = data_calgas{:,:};
calgas_shift_time = data_calgas(:,1);
F_calgases = data_calgas(:,2:4);
% 
y_calgases = zeros(length(calgas_shift_time),num_gases);
for i = 1:length(calgas_shift_time)
    y_calgases(i,:) = (F_calgases(i,1)*y_air + F_calgases(i,2)*y_h2 + F_calgases(i,3)*y_biogas) / (sum(F_calgases(i,:)));
end


% use the MS data or TJx data
MS_data = 0;        % 0 for TJx, 1 for QGA export
if MS_data == 1
    % fill in file name for MS dataset
    QGA_filepattern = '*methanotrophExp*';
    % the difference with the TJx data runtime (+ means MS = later)
    t_MS_data_offset = 62.5;                            % hours

    % load calibration dataset
    [t_MS_cal, y_cal_QGA] = QGA_load(QGA_filepattern, 0, num_compounds);
    t_MS_cal =  t_MS_cal + t_MS_data_offset;
end

% make new headers for the MS data --> use the right sequence 
MS_out_head = strcat('y_', compounds, '_out');
MS_cal_head = strcat('y_', compounds, '_cal');

% make new headers for the pumps --> use the right sequence 
Pump_tot_head = {'XPump1X_tot', 'Base_tot', 'AF_tot', 'Feed_tot', 'Outflow_tot', 'Acid_tot'};
Pump_PV_head = {'XPump1X_PV', 'Base_PV', 'AF_PV', 'Feed_PV', 'Outflow_PV', 'Acid_PV'};

% do we do fluctuations?
fluctuations = 0;

% interested in mass transfer calculations?
mass_transfer_calcs = 0;

% steady-state moments
SS_datatable = readtable(file_path, 'Sheet', 'steady-states');
SS_times = SS_datatable{:,4};
SS_reactor = SS_datatable{:,1};
SS_data = zeros(length(SS_reactor), 2*(length(compounds)+1)+4+3*length(compounds)+3);
ss_data_idx = 1;


%% loop over the files
for file = 1:n_files
    file_name = file_list(file).name;
    reactor = str2double(file_name(3));

    if reactor == 2
        aa = 1;
    end
    % load our dataset from TJx
    file_path = append(path, '\',raw_data_folder,'\', file_name);
    [data_table, headers] = load_data(file_path, MFC_head, MS_out_head, MS_cal_head, Pump_tot_head, Pump_PV_head, time_start, time_end, MFC_gas_shift_time);
    
    %% extract variables
    time = data_table{:,"RunTime"};                     % time [h]
    time = nonzeros(time); data_table = data_table(1:length(time),:);
    
    % there was an annoying time reset, correct for that
    [~, idx_time_reset] = min(diff(time));
    time(idx_time_reset+1:end) = time(idx_time_reset+1:end) + time(idx_time_reset);
    % and another time for reactor 6 and 8 because of the late inoculum
    if (reactor == 6) || (reactor == 8)
        [~, idx_time_reset] = min(diff(time));
        time(idx_time_reset+1:end) = time(idx_time_reset+1:end) + time(idx_time_reset);
    end

    % extract some other variables
    pH =  data_table{:,"pH_PV"};                        % pH
    Temp = data_table{:,"Temp_PV"};                     % Temperature [degC]
    Agit = data_table{:,"Agitation speed"};             % Agitation [rpm]
    DO = data_table{:,"DO_PV"};                         % DO (% saturation)
    base_tot = data_table{:, "Base_tot"} - data_table{1, "Base_tot"};
    base_feed = data_table{:, "Base_PV"};

    %% get the inlet gas flow
    
    % take the MFC data from TJx software
    F_gas_in = data_table{:,MFC_head([1,3,5])};

    % set up correction factors for the MFC flows [air, biogas, h2 ]
    MFC_cor_facs = data_mfc(reactor,:);
    MFC_cor_facs = reshape(MFC_cor_facs, 2,3)'; 
    for i = 1:size(F_gas_in,2)
        F_gas_in(:,i) = F_gas_in(:,i) * MFC_cor_facs(i,1) + MFC_cor_facs(i,2);
    end

    %% calculate gas inlet composition

    % get amount of each gas going in
    F_gases_in = (F_gas_in(:,1)*y_air + F_gas_in(:,2)*y_biogas + F_gas_in(:,3)*y_h2 ); % [mL/min]
    % divide by total to get composition
    F_gas_in_tot = sum(F_gas_in,2);   
    y_gas_in = F_gases_in./F_gas_in_tot; 


    %% calculate off-gas flow and composition

    neglect_water = 1;
    ind_water = 2;
    if neglect_water == 1, ind_gas = 2; else ind_gas = 1; end
    
    % make a vector for the calibration gas composition as function of
    % time. This depends on the length of the y_calgas and thus where
    % we read it from
    if MS_data == 0         % read from TJx file

        y_calgas = zeros(length(time),length(y_calgases));                 % fill a matrix with the compositions
        
        % get indices where the calgas was changed
        ind_gasshift = zeros(size(calgas_shift_time));
        for i = 1:numel(calgas_shift_time)
            [~, ind_gasshift(i)] = min(abs(time - calgas_shift_time(i)));                 % locate index where the gas shift is
        end
        ind_gasshifts = [ind_gasshift; length(time) ];             % add beginning and end

        % fill matrix with the calgas composition
        for i = 1:length(ind_gasshift)
            y_calgas(ind_gasshifts(i):ind_gasshifts(i+1)-1, :) = repmat(y_calgases(i,:), ind_gasshifts(i+1)-ind_gasshifts(i), 1);
        end

    else                    % take QGA file
        [~, ind_gasshift] = min(abs(t_MS_cal - t_gas_shift));               % locate index where the gas shift is
        y_calgas = zeros(length(t_MS_cal),length(y_calgas1));             % fill a matrix with the compositions

        y_calgas = zeros(length(time),length(y_calgas1));                 % fill a matrix with the compositions
        [~, ind_gasshift] = min(abs(time - t_gas_shift));                 % locate index where the gas shift is
        ind_gasshifts = [1, ind_gasshift, length(t_MS_cal) ];             % add beginning and end
        % fill matrix with the calgas composition

        for i = 1:length(ind_gasshift)+1
            y_calgas(ind_gasshifts(i):ind_gasshifts(i+1)-1, :) = repmat(y_calgas2(i,:), ind_gasshifts(i+1)-ind_gasshifts(i), 1);
        end
    end

    % get off-gas data from TJx or MS (when 1)
    if MS_data == 0
        % TJx file MS data
        y_out_MS = data_table{:, MS_out_head(1:end)}/100;               % Composition of gases out 
        y_cal_MS = data_table{:, MS_cal_head(1:end)}/100;               % Composition of MS calibration gas out 
        cal_corr_fac = y_cal_MS./(sum(y_cal_MS,2))./y_calgas(:,1:end);   % Correction factor for calibration gas
        % if we neglect water, then temporarily delete the columns, do the
        % calculations and add later on. Else just do the calculations and assume a factor of 1. 
        if neglect_water == 1
            cal_corr_fac(:,ind_water) = []; 
            y_out_MS(:,ind_water) = []; 
            y_out_MS_corr = y_out_MS./cal_corr_fac;                               % Corrected outflow reading
            y_gas_out = y_out_MS_corr./sum(y_out_MS_corr,2,'omitnan');                      % Outflow composition
            y_gas_out = [y_gas_out(:,1), zeros(size(y_gas_out,1),1), y_gas_out(:,2:end)];
        else
            cal_corr_fac(:,ind_water) = ones(size(y_out_MS,1), 1);
            y_out_MS_corr = y_out_MS./cal_corr_fac;                               % Corrected outflow reading
            y_gas_out = y_out_MS_corr./sum(y_out_MS_corr,2,'omitnan');                      % Outflow composition
        end

    else
        % load MS dataset dataset
        [t_MS_out, y_out_QGA] = QGA_load(QGA_filepattern, reactor, num_compounds);
        t_MS_out =  t_MS_out + t_MS_data_offset;
        cal_corr_fac = y_cal_QGA(:,1:end)./(sum(y_cal_QGA(:,1:end),2))./y_calgas(:,ind_gas:end);   % Correction factor for calibration gas
        cal_corr_fac_interp = interp1(t_MS_cal, cal_corr_fac, t_MS_out);      % interpolate calibration reading to current readings
        y_out_MS_corr = y_out_QGA(:,1:end)./cal_corr_fac_interp;        % Corrected outflow reading
        y_gas_out_QGA = y_out_MS_corr./sum(y_out_MS_corr,2);                  % Outflow composition
        y_gas_out = interp1(t_MS_out, y_gas_out_QGA, time, 'linear');         % interpolate to TJx sample moments
    end
    y_gas_out(isnan(y_gas_out)) = 0;

    %% locate fluctuation area
    if fluctuations == 1
        % get indices of fluctuation start/stop time
        [~, ind_fluct_start] = min(abs(time - t_fluct_start));               % locate index where the gas shift is
        [~, ind_fluct_end] = min(abs(time - t_fluct_end));                   % locate index where the gas shift is
        % duration of fluctuations
        t_fluct = time(ind_fluct_end) - time(ind_fluct_start);               % h
        n_movmean = 1000;
        % calculate a moving mean gas inflow rate during that period
        F_gas_in(ind_fluct_start:ind_fluct_end,:) = movmean(F_gas_in(ind_fluct_start:ind_fluct_end,:), n_movmean); % mL/min

    end
    

    %% convert gas in and out to mmol/min
    Temp_lab = 0+273.15;                                                    % MFC temperature [degC]
    R = 8.314;                                                              % ideal gas constant [J/K/mol]    
    p = 101325;                                                             % pressure [Pa]
    c_gas_in = p./(R*Temp_lab);                                              % inlet gas conc [mol/m3]
    c_gas_out = p./(R*(Temp+273.15));                                              % inlet gas conc [mol/m3]
    n_gases_in = F_gas_in_tot.*y_gas_in.*c_gas_in*1e-6*1000;                 % [mmol/min] of each gas in (1e-6 for mL --> m3) (1e3 for mol --> mmol) 
    
    % gas conservation via N2 
    F_gas_out = F_gas_in_tot .* y_gas_in(:,idx_gas_cons) .* c_gas_in ./ (y_gas_out(:,idx_gas_cons) .* c_gas_out);              % mL/min
%     n_gases_out = F_gas_out.*y_gas_out.*c_gas_in*1e-6*1000;                 % [mmol/min] of each gas out (1e-6 for mL --> m3) (1e3 for mol --> mmol) 
    n_gases_out = F_gas_out.*y_gas_out.*c_gas_out*1e-6*1000;


    %% calculate gas uptake rates
    Volume = 1;                                                         % L
    uptake_rates = -1*(n_gases_in - n_gases_out)/Volume*60*24;          % mmol/L/d

    % correct rates between logical values
    for i = 1:size(uptake_rates,1)
        for j = 1:size(uptake_rates,2)
            if uptake_rates(i,j) < r_mins(j), uptake_rates(i,j) = NaN; end
            if uptake_rates(i,j) > r_max(j), uptake_rates(i,j) = NaN; end
        end
    end 

    % correct H2 based on rate between 110 and 120 h
    reactor_h2_cor = [1, 2];
    if reactor == any(reactor_h2_cor)
        time_h2_cor = find(time > 112 & time < 115);
        h2_baseline = mean(uptake_rates(time_h2_cor,1), 'omitnan');
        uptake_rates(:,1) = uptake_rates(:,1) - h2_baseline;
        n_gases_out(:,1) = n_gases_out(:,1) - h2_baseline*Volume/(24*60);
    end


%     % correct some manually
    if reactor == 8
        ch4_baseline = mean(uptake_rates(2000:6000,3), 'omitnan');
        uptake_rates(:,3) = uptake_rates(:,3) - ch4_baseline;
        n_gases_out(:,3) = n_gases_out(:,3) - ch4_baseline*Volume/(24*60);

    end
    
    
    rel_uptake_rates = (n_gases_in - n_gases_out)./n_gases_in * 100;    % percent conversion
  

    %% Interpolate OD and dilution rate over time
    
    % get data and time of OD samples from reactor
    OD_data_reactor = OD_data(:,reactor); 
    OD_data_reactor(OD_data_reactor == 0);
    t_OD_reactor = t_OD(1:length(OD_data_reactor));
    
    % interpolate data
    OD = interp1(t_OD_reactor, OD_data_reactor, time, 'pchip');         % OD
    OD = smoothdata(OD, 'smoothingfactor',0.05);                        % OD
    cx = OD*gL_OD;                                                      % g/L
    Dil = interp1(t_OD, Dil_data(:,reactor), time, 'previous');         % 1/h
    
    % calculate growth rate
    dMxdt = gradient(cx, time);                                       % g/L/h

    mu = (dMxdt + Dil.*cx)./cx;                                         % gx/gx/h
    MWx = 24.6;                                                         % g/mol
    mu_qrate = Dil./MWx*1000;                                            % mmolx/gx/h
    mu_rrate = Dil.*cx/MWx*1000*24;                                      % mmol/L/d
    r_rates = [uptake_rates, mu_rrate];                                 % mmol/L/d
    q_rates = r_rates./cx;                                              % mmol/gx/d


    %% predict community composition
    % assume: all H2 by cN, all CH4 by Mc
    % use stoichiometry from the excel sheet
    % cN: H2/x = -5.4. Mc: CH4/x = -1.92
    rx_nec_exp = r_rates(:,1)/-5.4;  rx_nec_exp(rx_nec_exp<0) = 0 ;
    rx_ch4_exp = r_rates(:,3)/-1.92; rx_ch4_exp(rx_ch4_exp<0) = 0 ;

    fracs = [rx_nec_exp./(rx_nec_exp+rx_ch4_exp), rx_ch4_exp./(rx_nec_exp+rx_ch4_exp)]*100;       % frac CN, frac Mc
    cx_Cn = OD.*fracs(:,1)/100;
    cx_Mc = OD.*fracs(:,2)/100;
    ratio = cx_Cn./cx_Mc;
    

    %% Carbon balance and DoR balance
             %  [H2,  H2O, CH4, N2,  O2,  Ar,  CO2,  X]
    C_count =   [0,   0,    1,   0,  0,   0,   1,    1];
    E_count =   [2,   0,    8,   0,  -4,  0,   0,    4+1.8+0.5*-2+0.2*-3];

    C_bal_r = r_rates.*C_count;
    E_bal_r = r_rates.*E_count;
    
 


    %% make area graph
    compounds_mu = [compounds, 'Biomass']; 
    cmp = parula(length(compounds_mu));
    fig = figure();
        

   % OD data and mu
    subplot(2,2,1)
    colororder({'r','k'})
    yyaxis left
    plot(time, OD, 'r-', t_OD_reactor, OD_data_reactor, 'ro');
    xlabel('time (h)'); ylabel('OD_{600}');
    ylim([0, 20]);
    yyaxis right
    plot(time, mu*24, 'k--', time, Dil*24, 'k-');
    ylabel('\mu, D (d^{-1})'); ylim([0, 5]);
    legend('OD', 'OD data', '\mu', 'D', 'location', 'best');
    title(['Biomass R0' num2str(reactor)]);
    xlim([250, 760]);
    set(gca, 'FontSize', 15);

    % gas uptake rates
    subplot(2,2,2)
    [a_p, a_n] = area_graph(time, r_rates, compounds_mu, 0);
    xlabel('time (h)'); ylabel('Volumetric rates (mmol/L/d)')
    ylim([-1000, 500]);
    title(['Rates R0' num2str(reactor)]);
    xlim([250, 760]);
    set(gca, 'FontSize', 15);

    % Carbon balance data
    subplot(2,2,3)
    [a_p, a_n] = area_graph(time, C_bal_r, compounds_mu, 1);
    xlabel('time (h)'); ylabel('C-balance (mmol_C/L/d)')
    ylim([-200, 200]);
    title(['Carbon bal R0' num2str(reactor)]);
    xlim([250, 760]);
    set(gca, 'FontSize', 15);

    % Redox balance data
    subplot(2,2,4)
    [a_p, a_n] = area_graph(time, E_bal_r, compounds_mu, 1);
    xlabel('time (h)'); ylabel('e^--balance (mmol_{e^-}/L/d)')
    ylim([-2e-4, 2e4]);
    title(['Degree of reduction bal R0' num2str(reactor)]);
    ylim([-2000, 2000]);
    xlim([300, 760]);
    set(gca, 'FontSize', 15);

    set(gcf,'position', [-2.681400000000000e+03    -1.110000000000000e+02     2.038400000000000e+03     1.017600000000000e+03]);
    if store_results == 1
        fig_name = fullfile(results_folder, sprintf('R0%d_fermentation_results.png', reactor));
        saveas(gcf,fig_name);
    end

%%
    
    dt = time(1000)-time(999);
    if plot_average_graph == 1
        win = [24*3/dt, 0];                             % 3 day prior to datapoint, 0 after
        r_rates_av = movmean(r_rates,win, 'omitnan');
        C_bal_r_av = movmean(C_bal_r,win, 'omitnan');
        E_bal_r_av = movmean(E_bal_r,win, 'omitnan');
    
        figure()
        subplot(2,2,1)
        colororder({'r','k'})
        yyaxis left
        plot(time, OD, '-r', t_OD_reactor, OD_data_reactor, 'ro'); hold on;
        xlabel('time (h)'); ylabel('OD_{600}');
        ylim([0, 20]);
        yyaxis right
        plot(time, mu*24, 'k--', time, Dil*24, 'k-');
        ylabel('\mu, D (d^{-1})'); ylim([0, 5]);
        legend('OD', 'OD data', '\mu', 'D', 'location', 'best');
        title(['Biomass R0' num2str(reactor)]);
        xlim([0, 1100]);
        
        % gas uptake rates
        subplot(2,2,2)
        [a_p, a_n] = area_graph(time, r_rates_av, compounds_mu, 0);
        xlabel('time (h)'); ylabel('Volumetric rates (mmol/L/d)')
        ylim([-1000, 500]);
        title(['Mov mean Rates R0' num2str(reactor)]);
        xlim([0, 1100]);
    
        % Carbon balance data
        subplot(2,2,3)
        [a_p, a_n] = area_graph(time, C_bal_r_av, compounds_mu, 1);
        xlabel('time (h)'); ylabel('C-balance (mmol_C/L/d)')
        ylim([-200, 200]);
        title(['Mov mean Carbon bal R0' num2str(reactor)]);
        xlim([0, 1100]);
    
        % Redox balance data
        subplot(2,2,4)
        [a_p, a_n] = area_graph(time, E_bal_r_av, compounds_mu, 1);
        xlabel('time (h)'); ylabel('e^--balance (mmol_{e^-}/L/d)')
        ylim([-2e-4, 2e4]);
        title(['Mov mean DoR bal R0' num2str(reactor)]);
        ylim([-2000, 2000]);
        xlim([0, 1100]);
 

        set(gcf,'position', [-2.681400000000000e+03    -1.110000000000000e+02     2.038400000000000e+03     1.017600000000000e+03]);
        if store_results == 1
            fig_name = fullfile(results_folder, sprintf('R0%d_fermentation_results_mean.png', reactor));
            saveas(gcf,fig_name);
        end
       close(2)
    end

    %% make gas uptake rate graph next to each reactor
       % gas uptake rates
    
%     if reactor == 5   
        f_overview = figure(3);
        subplot(1,2,1)
        ap = area(time, [cx_Cn, cx_Mc]);  hold on;
        ap(1).FaceColor = [231,191,59]/255;    ap(2).FaceColor = [204,104,102]/255;
        ap(1).LineWidth = 0.00000001;     ap(2).LineWidth = 0.00000001;
        ap(1).EdgeColor = [231,191,59]/255;    ap(2).EdgeColor = [204,104,102]/255;
        plot(time, OD, 'k--', 'LineWidth', 2)
        plot(t_OD, OD_data_reactor, 'ko', 'markerfacecolor','k');
        xlabel('Time (h)'); ylabel('Biomass concentration (OD_{600})');
        ylim([0, 12]);     xlim([250, 760]);
%         title(['Biomass composition R' num2str(reactor)]);
        legend({'\itC. necator\rm', '\itM. capsulatus\rm', 'OD_{600} interp.', 'OD_{600}'});
        set(gca,'fontsize',18);
        set(gca,'fontname','times')
    
      
        % figure with microbial composition over time
        subplot(1,2,2)
        r_rates_small = r_rates(:,[1,3,5,7,8]);
        compounds_small = compounds_mu([1,3,5,7,8]);
        [a_p, a_n, l] = area_graph(time, r_rates_small, compounds_small, 0);
        set(l, 'location', 'southwest')
        xlabel('Time (h)'); ylabel('Volumetric rates (mmol L^{-1} d^{-1})')
        ylim([-750, 250]);
%         title(['Rates R0' num2str(reactor)]);
        xlim([250, 760]);%     plot(time, ratio, '--', 'linewidth',0.1);
        set(gca,'fontsize',18);
        set(gca,'fontname','times')
    
        set(gcf,'position', 1.0e+03 *[   -2.6814    0.2042    2.0384    0.7024]);
        if store_results == 1
            fig_name = fullfile(results_folder, sprintf('R0%d_overview.png', reactor));
            saveas(gcf,fig_name);
        end
        close(3)
%     end


    %% make for matlab as struct
    if store_results == 1
        data = [];
        data.time = time;
        data.OD = OD;
        data.Dil = Dil;
        data.mu = mu;
        data.Temp = Temp;
        data.Agit = Agit;
        data.DO = DO;
        data.pH = pH;
        data.r_rates = r_rates;
        data.q_rates = q_rates;
        data.F_gas_in_tot = F_gas_in_tot;
        data.y_gas_in = y_gas_in;
        data.F_gas_out = F_gas_out;
        data.y_gas_out = y_gas_out;
        data.y_gas_out = y_gas_out;
        
        data_filename_mat = fullfile(results_folder, sprintf('R0%d_processed_data.mat', reactor));
        save(data_filename_mat, 'data'); % Save .mat file
    
        %% write in CSV
        if mass_transfer_calcs == 1
            r_headers = "r_" + compounds_mu;  % Rates
            q_headers = "q_" + compounds_mu;  % Uptake rates
            y_gas_in_headers = "y_" + compounds_mu(1:end-1) + "_in";  % Gas composition in
            y_gas_out_headers = "y_" + compounds_mu(1:end-1) + "_out"; % Gas composition out
            base_headers = {'time', 'OD', 'c_x', 'Dil', 'mu', 'Temp', 'Agit', 'DO', 'pH'};
            mt_headers = {'c_h2', 'c_o2', 'c_co2', 'kla_o2', 'kla_h2'};
            headers = [base_headers, r_headers, q_headers, mt_headers, "F_gas_in_tot", y_gas_in_headers, "F_gas_out", y_gas_out_headers];
    
            % units
            base_units = {'hours', '-', 'g/L', '1/h', '1/h', 'degC', 'rpm', '%sat', '-'};
            r_units = repmat({'mmol/L/d'}, 1, numel(r_headers));  % r_rates units
            q_units = repmat({'mmol/gx/h'}, 1, numel(q_headers)); % q_rates units
            y_gas_units = repmat({'-'}, 1, numel(y_gas_in_headers)); % Gas composition is dimensionless
            F_gas_units = {'mL/min'}; % Flow rate unit
            mt_units = {'g/L', 'g/L', 'g/L', '1/h', '1/h'};
            units = [base_units, r_units, q_units, mt_units, F_gas_units, y_gas_units, F_gas_units, y_gas_units];
            dataset = [time, OD, cx, Dil, mu, Temp, Agit, DO, pH, r_rates, q_rates, conc_i(:,[1,4,6]),kla_o2, kla_h2, F_gas_in_tot, y_gas_in, F_gas_out, y_gas_out];
        else
            r_headers = "r_" + compounds_mu;  % Rates
            q_headers = "q_" + compounds_mu;  % Uptake rates
            y_gas_in_headers = "y_" + compounds_mu(1:end-1) + "_in";  % Gas composition in
            y_gas_out_headers = "y_" + compounds_mu(1:end-1) + "_out"; % Gas composition out
            base_headers = {'time', 'OD', 'c_x', 'Dil', 'mu', 'Temp', 'Agit', 'DO', 'pH'};
            headers = [base_headers, r_headers, q_headers, "F_gas_in_tot", y_gas_in_headers, "F_gas_out", y_gas_out_headers];
    
            % units
            base_units = {'hours', '-', 'g/L', '1/h', '1/h', 'degC', 'rpm', '%sat', '-'};
            r_units = repmat({'mmol/L/d'}, 1, numel(r_headers));  % r_rates units
            q_units = repmat({'mmol/gx/h'}, 1, numel(q_headers)); % q_rates units
            y_gas_units = repmat({'-'}, 1, numel(y_gas_in_headers)); % Gas composition is dimensionless
            F_gas_units = {'mL/min'}; % Flow rate unit
            units = [base_units, r_units, q_units, F_gas_units, y_gas_units, F_gas_units, y_gas_units];
            dataset = [time, OD, cx, Dil, mu, Temp, Agit, DO, pH, r_rates, q_rates, F_gas_in_tot, y_gas_in, F_gas_out, y_gas_out];
        end
        
        % Combine headers and data
        dataset = [headers; units; num2cell(dataset)];
        data_filename_csv = fullfile(results_folder, sprintf('R0%d_processed_data.csv', reactor));
       
        % Write to CSV
        writematrix(dataset, data_filename_csv);
        
        % write to excel
        sheetname = sprintf('reactor R0%d', reactor);
%         xlswrite("results/Processed_data.xlsx",dataset, 'sheet', sheetname);


        %% Find steady-state data
    
        idx_ss_r = find(SS_reactor == reactor);       % find which index applies for the current reactor
        time_ss = SS_times(idx_ss_r);                 % get the right timings

        for i = 1:length(time_ss)
            % get indices for time vector
            [~, idx_ss_end] = min( abs(time - time_ss(i)));  % should be the end data point of the steady-state
            idx_ss_start = round(idx_ss_end - 3*1*24 / dt, 0);
            % get indices for OD measurements
            [~, idx_ss_end_OD] = min( abs(t_OD - time_ss(i)));
            [~, idx_ss_start_OD] = min( abs(t_OD - (time_ss(i) - 3*1*24)));

            % outlier removal
            time_vec = time(idx_ss_start:idx_ss_end);
            r_rates_upd = zeros(length(time_vec), num_gases + 1);

            for j = 1:num_gases+1
                rate_vec = r_rates(idx_ss_start:idx_ss_end,j);
                TF = isoutlier(rate_vec,"gesd");
                rate_vec(TF) = NaN;
                r_rates_upd(:,j) = rate_vec;
            end
            
            % get data 
            % rates + OD
            r_rates_av = mean(r_rates_upd, 'omitnan');
            r_rates_std = std(r_rates_upd, 'omitnan');            
            OD_int_av = mean(OD(idx_ss_start:idx_ss_end));
            OD_int_std = std(OD(idx_ss_start:idx_ss_end));
            OD_meas_av = mean(OD_data(idx_ss_start_OD:idx_ss_end_OD,reactor));
            OD_meas_std = std(OD_data(idx_ss_start_OD:idx_ss_end_OD,reactor));
            % gases
            gases_in = mean(n_gases_in(idx_ss_start:idx_ss_end,:))/(Volume)*60*24;                                   % mmol/L/d
            gases_out = mean(n_gases_out(idx_ss_start:idx_ss_end,:))/(Volume)*60*24;                                 % mmol/L/d
            y_gas_out_ss = mean(y_gas_out(idx_ss_start:idx_ss_end,:));                                 % -
            % base feed
            base_tot_ss = (base_tot(idx_ss_end)-base_tot(idx_ss_start)) / (3*1*24); % mL / h
            base_feed_av = mean(base_feed(idx_ss_start:idx_ss_end, :), 'omitnan');            % mL / h
            base_feed_std = std(base_feed(idx_ss_start:idx_ss_end, :), 'omitnan');            % mL / h

            SS_data(ss_data_idx,:) = [OD_meas_av, OD_meas_std, OD_int_av, OD_int_std, r_rates_av, r_rates_std, ...
                gases_in, gases_out, y_gas_out_ss, base_tot_ss, base_feed_av, base_feed_std ];
            ss_data_idx = ss_data_idx+1;

        end

     %% figures chee7111
% figure()        
% subplot(1,3,1)
% histogram(-1*r_rates(idx_ss_start:idx_ss_end,1))
% xlabel("H_2 uptake (mmol/L/h)")
% ylabel('# values')
% set(gca,'fontsize', 16)
% title(sprintf(['Mean = %.2f   Std = %.2f  \n ' ...
%                'Skew = %.2f   Kurt = %.2f'], ...
%                mean(r_rates(idx_ss_start:idx_ss_end,1),'omitnan'), std(r_rates(idx_ss_start:idx_ss_end,1),'omitnan'), skewness(r_rates(idx_ss_start:idx_ss_end,1)), kurtosis(r_rates(idx_ss_start:idx_ss_end,1)) ), ...
%             'FontSize', 18)
% 
% subplot(1,3,2)
% histogram(1*r_rates(idx_ss_start:idx_ss_end,7))
% xlabel("CO_2 production (mmol/L/h)")
% ylabel('# values')
% set(gca,'fontsize', 16)
% title(sprintf(['Mean = %.2f   Std = %.2f  \n ' ...
%                'Skew = %.2f   Kurt = %.2f'], ...
%                mean(r_rates(idx_ss_start:idx_ss_end,7),'omitnan'), std(r_rates(idx_ss_start:idx_ss_end,7),'omitnan'), skewness(r_rates(idx_ss_start:idx_ss_end,7)), kurtosis(r_rates(idx_ss_start:idx_ss_end,7)) ), ...
%             'FontSize', 18)
% 
% subplot(1,3,3)
% histogram(1*r_rates(idx_ss_start:idx_ss_end,8))
% xlabel("Growth (mmol/L/h)")
% ylabel('# values')
% set(gca,'fontsize', 16)
% title(sprintf(['Mean = %.2f   Std = %.2f  \n ' ...
%                'Skew = %.2f   Kurt = %.2f'], ...
%                mean(r_rates(idx_ss_start:idx_ss_end,8)), std(r_rates(idx_ss_start:idx_ss_end,8)), skewness(r_rates(idx_ss_start:idx_ss_end,8)), kurtosis(r_rates(idx_ss_start:idx_ss_end,8)) ), ...
%             'FontSize', 18)
% 
% set(gcf,'position', 1e3*[ -2.5838    0.3162    1.9376    0.4656])
% saveas(gcf, 'histograms.png')
% 
% 
% 
% figure()
% boxplot(rate_vec);
% ylabel('H_2 uptake (mmol/L/h)')
% set(gca,'fontsize', 16)
% saveas(gcf, 'time_course_H2_boxplot.png')
% 
% figure()
% plot(time_vec, rate_vec, 'b-')
% xlabel('time (h)')
% ylabel('H_2 uptake (mmol/L/h)')
% set(gca,'fontsize', 16)
% saveas(gcf, 'time_course_H2.png')
% hold on;
% plot( time_vec(TF) , rate_vec(TF),"x")
% legend("Original Data","Outlier Data", 'location','southeast')
% 
% saveas(gcf, 'time_course_H2_outliers.png')
% 
% 
% 
% 
% 
% 
% figure()        
% subplot(1,2,1)
% histogram(-1*r_rates(idx_ss_start:idx_ss_end,1))
% xlabel("H_2 uptake (mmol/L/h)")
% ylabel('# values')
% set(gca,'fontsize', 16)
% title(sprintf(['Mean = %.2f   Std = %.2f  \n ' ...
%                'Skew = %.2f   Kurt = %.2f'], ...
%                mean(-1*r_rates(idx_ss_start:idx_ss_end,1),'omitnan'), std(r_rates(idx_ss_start:idx_ss_end,1),'omitnan'), skewness(r_rates(idx_ss_start:idx_ss_end,1)), kurtosis(r_rates(idx_ss_start:idx_ss_end,1)) ), ...
%             'FontSize', 18)
% 
% subplot(1,2,2)
% histogram(rate_vec_upd)
% xlabel("H_2 uptake (mmol/L/h)")
% ylabel('# values')
% set(gca,'fontsize', 16)
% title(sprintf(['Mean = %.2f   Std = %.2f  \n ' ...
%                'Skew = %.2f   Kurt = %.2f'], ...
%                mean(rate_vec_upd,'omitnan'), std(rate_vec_upd,'omitnan'), skewness(rate_vec_upd), kurtosis(rate_vec_upd ) ), ...
%             'FontSize', 18)
% set(gcf,'position', 1e3*[   -2.8430    0.3642    1.1872    0.5192]);
% saveas(gcf,'Histogram_H2_upd.png')

    end
   close(1)




end

if store_results == 1
    %% make table for SS data
    r_headers_av = "r_av_" + compounds_mu;
    r_headers_std = "r_std_" + compounds_mu;
    OD_headers = ["OD_meas_av", "OD_meas_std", "OD_int_av", "OD_int_std"];
    gas_in_head = "n_" + compounds + "_in";
    gas_out_head = "n_" + compounds + "_out";
    y_gas_out_head = "y_" + compounds + "_out";
    base_head = ["Base tot", "Base PV av", "Base PV std"];

    SS_data_headers = [OD_headers, r_headers_av, r_headers_std, gas_in_head, gas_out_head, y_gas_out_head, base_head];
    SS_data = array2table(SS_data, 'VariableNames', SS_data_headers);
    SS_data_table = [SS_datatable(:, 1:5), SS_data];
    
    % write new table
    writetable(SS_data_table, "results\Processed_data.xlsx", 'sheet',"Steady-state-data");

end



function [data_table, newHeaders] = load_data(file_path, MFC_head, MS_out_head, MS_cal_head, Pump_tot_head, Pump_PV_head, time_start, time_end, MFC_gas_shift_time)
    data_table = readtable(file_path, 'VariableNamingRule', 'preserve');
    oldHeaders = data_table.Properties.VariableNames(1:end); % Extract headers


    % Filter data_table based on the specified time range
    if ~isempty(time_start) && time_start > 1
        time = data_table.RunTime;  % Extract time column [h]
    
        % Find indices where time is within the desired range
        ind_time_correct = (time > time_start) & (time < time_end);
    
        % Apply logical indexing directly (more efficient than find)
        data_table = data_table(ind_time_correct, :);
        % Update time vector again for later on
        time = data_table.RunTime;  % Extract time column [h]
    end


    % Define old names that need to be replaced
    old_MS_out = {'MS_1_OUT', 'MS_2_OUT', 'MS_3_OUT', 'MS_4_OUT', 'MS_5_OUT', 'MS_6_OUT', 'MS_7_OUT'};
    old_MS_cal = {'MS_1_Cal', 'MS_2_Cal', 'MS_3_Cal', 'MS_4_Cal', 'MS_5_Cal', 'MS_6_Cal', 'MS_7_Cal'};
    old_MFC_head = {'Air PV', 'Air SP', 'CO PV', 'CO SP', 'H2 PV', 'H2 SP'};
    old_pump_PV_head = {'Acid flow PV', 'Base flow PV', 'AF flow PV', 'Feed1 Flow PV', 'Feed2 Flow PV', 'Feed3 Flow PV'};
    old_pump_tot_head = {'Pump1_Total', 'Pump2_Total', 'Pump3_Total', 'Pump4_Total', 'Pump5_Total', 'Pump6_Total'};


    % Update headers for MS data (can handle independently)
    for i = 1:length(old_MS_out)
        idx_out = find(strcmp(oldHeaders, old_MS_out{i}));              % check whether we now at MS out
        idx_cal = find(strcmp(oldHeaders, old_MS_cal{i}));          % check whether we now at MS cal
        if ~isempty(idx_out), oldHeaders{idx_out} = MS_out_head{i};   end
        if ~isempty(idx_cal), oldHeaders{idx_cal} = MS_cal_head{i};   end
    end

    % Update headers for MS data (can handle independently - only 6 entries)
    for i = 1:length(old_pump_tot_head)
        idx_pump_pv = find(strcmp(oldHeaders, old_pump_PV_head{i}));          % check whether we now at MS cal
        idx_pump_tot = find(strcmp(oldHeaders, old_pump_tot_head{i}));          % check whether we now at MS cal
        idx_mfc = find(strcmp(oldHeaders, old_MFC_head{i}));          % check whether we now at MS cal
        if ~isempty(idx_mfc), oldHeaders{idx_mfc} = MFC_head{i};   end
        if ~isempty(idx_pump_pv), oldHeaders{idx_pump_pv} = Pump_PV_head{i};   end
        if ~isempty(idx_pump_tot), oldHeaders{idx_pump_tot} = Pump_tot_head{i};   end

    end
    data_table.Properties.VariableNames = oldHeaders;
    newHeaders = data_table.Properties.VariableNames; % Extract headers

    if ~isempty(MFC_gas_shift_time)
        % modify the MS data to accomodate the gas shift
        ind_knallgas = (time < MS_gas_shift_time(1));
        ind_biogas_h2 = (time > MS_gas_shift_time(1));
        
        % mark MS_7_OUT as 0 for the cases with knallgas
        % %           [H2,  N2, H2O  O2,   Ar,   CO2, CH4]
        data_table{ind_knallgas, MS_out_head(7)} = 0;
        data_table{ind_knallgas, MS_cal_head(7)} = 0;
    
        % shift ch4 data for the cases with biogas (from indices 4-7 to 3-6)
        % %           [H2,  H2O, CH4, N2, O2,   Ar,   CO2] --> biogas cases
        ch4_data = data_table{ind_biogas_h2, MS_out_head(3)};
        ch4_data_cal = data_table{ind_biogas_h2, MS_cal_head(3)};
        h2o_data = data_table{ind_biogas_h2, MS_out_head(2) };
        h2o_data_cal = data_table{ind_biogas_h2, MS_cal_head(3)};
        data_table{ind_biogas_h2, MS_out_head([2,4,5,6])} = data_table{ind_biogas_h2, MS_out_head(4:7)};
        data_table{ind_biogas_h2, MS_cal_head([2,4,5,6])} = data_table{ind_biogas_h2, MS_cal_head(4:7)};
        data_table{ind_biogas_h2, MS_out_head(7)} = ch4_data;
        data_table{ind_biogas_h2, MS_out_head(3)} = h2o_data;
        data_table{ind_biogas_h2, MS_cal_head(7)} = ch4_data_cal;
        data_table{ind_biogas_h2, MS_cal_head(3)} = h2o_data_cal;
    end


end

function [t, y_out] = QGA_load(QGA_file_pattern, reactor, num_compounds)

    % retrieve datasets
    raw_data_folder = 'raw_data\QGA';
    path = cd;
    unix_pattern = fullfile(path, raw_data_folder, QGA_file_pattern);
    % Get the list of files matching the pattern within the folder
    file_list = dir(unix_pattern);
    n_files = length(file_list);
    if reactor == 0
        stream_name = ['Stream ' num2str(reactor+7+0)];
    else
        stream_name = ['Stream ' num2str(reactor+7+1)];
    end


    for i = 1:n_files
        file_name = file_list(i).name;
        QGA_file_path = fullfile(path, raw_data_folder, file_name);
        % get the names of the sheets we have
        sheets = sheetnames(QGA_file_path);
        % if the sheets contain the stream number, then load
        if ismember(stream_name, sheets)
            data_MS = readtable(QGA_file_path, 'VariableNamingRule', 'preserve', 'Sheet',stream_name);
            
            % when we have more files for the same reactor, then append the
            % current datasets, else just take it unprocessed
            if i > 1
                % append y_out data with the new dataset
                y_out = [y_out ; data_MS{:,4:(4+num_compounds-1)}];
                t_current = data_MS{:,2}/3600;
                % get the time differences between the two files
                file_time = read_date_time(file_name);
                t_start = file_time + seconds(t_current(1));
                t_diff = hours(t_start - t_real_end);
                t = [t ; t_current + t_diff + t(end)];
                t_real_end = file_time + hours(t_current(end));

            else
                % get our data
                y_out = data_MS{:,4:(4+num_compounds-1)};
                t = data_MS{:,2}/3600;
                file_time = read_date_time(file_name);
                t_real_end = file_time + hours(t(end));
            end

        end
    end
end

function file_time = read_date_time(filename)

% Extract date and time parts using regular expressions
tokens = regexp(filename, '(\d{2}-\d{2}-\d{4}) (\d{1,2}-\d{2}-\d{2} (AM|PM))', 'tokens');

% Convert extracted values into datetime
if ~isempty(tokens)
    date_part = tokens{1}{1};  % '24-01-2025'
    time_part = tokens{1}{2};  % '9-22-12 AM'
    
    % Replace dashes with colons in time part and create datetime string
    time_part = strrep(time_part, '-', ':');
    datetime_str = [date_part, ' ', time_part];  % '24-01-2025 9:22:12 AM'
    
    % Convert to datetime object
    file_time = datetime(datetime_str, 'InputFormat', 'dd-MM-yyyy hh:mm:ss a');
    
else
    disp('Error: Could not extract time from filename.');
end


end



function [q_rates_fit] = kinetic_fitting_caps(y, c_data)

    % unpack concentration data
    c_o2 = c_data(:,1); 
    c_ch4 = c_data(:,2);

    % unpack y
    Ks_o2 = y(1);           % saturation concentration
    Ks_ch4 = y(2);          % 
    mu_max = y(3);
    Y_ch4_x = y(4);
    Y_o2_x = y(5);
%     Y_co2_x = y(6);
    Y = y(4:5);

    mu = mu_max .* c_o2./(c_o2+Ks_o2) .* c_ch4./(c_ch4+Ks_ch4);
    q_rates_fit = [mu.*Y', mu];

    

end


function [a_p, a_n, leg] = area_graph(time, data_s, compounds, error_check)

% smooth data bit to get clearer graphs
data_s = smoothdata(data_s, 'SmoothingFactor',0.1);


% set up data matrices that are postive and negative
data_pos = zeros(size(data_s));
data_neg = zeros(size(data_s));

% for each compound, find positive and negative data points
for cmpd = 1:size(data_s,2)
    % search for negative and positive data sets
    ind_data_neg = find(data_s(:,cmpd) < 0);
    ind_data_pos = find(data_s(:,cmpd) > 0);
    
    % put that data in our empty matrix. If there is none, it remains zeros.
    data_neg(ind_data_neg, cmpd) = data_s(ind_data_neg,cmpd);
    data_pos(ind_data_pos, cmpd) = data_s(ind_data_pos,cmpd);
end

% calculate mass balance error
if error_check == 1
    error = sum(data_pos,2) - abs(sum(data_neg,2));
    ind_error_neg = find(error > 0);
    ind_error_pos = find(error < 0);
    error_pos = zeros(size(error));  error_neg = zeros(size(error)); 
    error_pos(ind_error_pos) = abs(error(ind_error_pos)); 
    error_neg(ind_error_neg) = abs(error(ind_error_neg)); 
    
    compounds{end+1} = 'error';
    data_pos = [data_pos, error_pos];
    data_neg = [data_neg, -1*error_neg];
end

% make area graph for the mass balance
a_p = area( time , data_pos ); hold on;
a_n = area( time , data_neg ); hold on;

cmp = parula(size(data_s,2)+1);
cmp = cmocean('thermal', size(data_s,2)+1);
cmp(end,:) = [1,0,0];

if error_check == 0
    for cmpd = 1:size(data_s,2)
        a_p(cmpd).FaceColor = cmp(cmpd,:);
        a_p(cmpd).LineWidth = 0.00000001;
        
        a_n(cmpd).FaceColor = cmp(cmpd,:);
        a_n(cmpd).LineWidth = 0.00000001;
    end
else
    for cmpd = 1:size(data_s,2)+1
        a_p(cmpd).FaceColor = cmp(cmpd,:);
        a_p(cmpd).LineWidth = 0.00000001;
        
        a_n(cmpd).FaceColor = cmp(cmpd,:);
        a_n(cmpd).LineWidth = 0.00000001;
    end
end


leg = legend(a_p,compounds,'location','bestoutside'); grid on;

end


function H_temp = Henry(T)
% Henry const   O2,   H2,       CO2,   CH4
H_ref = [4.16e-07, 1.57E-08, 1.50E-05, 2.25E-07];       % Henry @ reference temp [g/L/Pa]
T_ref = 298.15;                                         % K
H_Tvar = [1500, 530, 2300, 1600];                       % Henry temperature var const [1/K] -d_solH/R = dH/d(1/T)
% Temperature in Kelvin

% calculate Henry @ temperature
H_temp = H_ref .* exp(H_Tvar .* (1./T - 1/T_ref));

end



function visc = viscosity(T)
    % Temperature in Kelvin
    Const = [-24.71, 4.209e3, 4.527e-2, -3.376e-5];     % Constants for water (Reid, 1987)
    
    visc = exp(Const(1)+Const(2)*T.^-1+Const(3).*T+Const(4)*T.^2);  % mPa.s
    visc = visc/1000;                                       % Pa.s
end


function diff = diffusion(T,visc)
    % diffusion coefficient as function of temperature and viscosity
    if nargin < 2                   % if viscosity is not specified
        mu_T = viscosity(T);        % water visc @ T in [Pa.s]
    else
        mu_T = visc;                % specified visc
    end

    % constants at 25 degC O2, H2, CO2, CH4
    D_const = [2.10, 4.5, 1.92, 1.49]*1e-9;       % diffusion const @ 25deg m2/s
    T_ref = 25+273.15;                      % ref temperature K
    mu_25 = viscosity(T_ref);               % Pa.s
    mu_T = viscosity(T);                    % Pa.s

    % viscosity can be specified for viscous media
    if size(visc) > 0       
        mu_T = visc;
    end

    diff = D_const.*T.*mu_25./(mu_T.*T_ref);    % m2/s
    
end